# SDPLO-RangeEV — Heads-Up Short Deck PLO5 bot

A range-aware expected-value bot for the TAMU Datathon Poker Bot Challenge.
`agent.py` keeps the starter's server plumbing untouched; only the three
strategy functions (and the team/bot names) were filled in. They delegate to
the `sdplo/` package.

> **Before submitting:** set `PARTICIPANT` in `agent.py` to your registered
> team name, then run `python -m pytest -q` and `./tools/check_build.sh`.

## Quick start

```bash
pip install -r requirements-dev.txt          # fastapi, uvicorn, pytest, httpx (numpy is in the base image)

python -m pytest -q                          # official server tests (test_agent.py)
python -m pytest -q tests/                   # strategy tests (31 tests)

python agent.py                              # bot on :5008
python baseline-bots/baseline_random.py      # opponent on :5009
python judge_engine.py --deals 1000          # full duplicate match
```

`requirements.txt` adds only `numpy` (unpinned, so the build reuses the copy
already in the tournament base image).

## Architecture

```
judge ──HTTP──> agent.py (unchanged plumbing)
                   │  new_half / choose_action / on_hand_end
                   ▼
              sdplo/bot.py  BotState ─── time governor + try/except + legality guard
                   │
   ┌───────────────┼───────────────────────────┬──────────────────────────┐
   ▼               ▼                           ▼                          ▼
history.py     opponent.py                ranges.py                  policy.py
action log →   online frequencies         particle filter over       EV of each legal action
contexts       (fold/call/raise per       opponent hands + Monte     (pot odds, fold equity,
               context, bluff share)      Carlo equity               realised equity) → choice
                                               │
                                     fasteval.py + tables.py
                                     vectorised evaluator, preflop tables
```

Game-state processing (`history.py`), opponent statistics (`opponent.py`),
range/equity estimation (`ranges.py`) and the decision rule (`policy.py`) are
separate modules; `bot.py` is the only glue, and `agent.py` the only interface.

### 1. Hand evaluation (`fasteval.py`)
A five-card score depends only on the rank multiset and whether all five
cards share a suit. Both are encoded additively (`Σ5^rank`, `Σ8^suit`), so a
hole pair's partial key plus a board triple's partial key gives the full key
by plain addition. numpy broadcasts the 10 × 10 Omaha (exactly 2 + 3)
combinations for whole batches of hands in one gather. Scores come from the
official `evaluator._score_ranks` and are tested equal to `omaha_score`;
batch speed is ~1 µs/hand vs ~38 µs for the reference.

### 2. Preflop tables (`tables.py`, `training/build_preflop.py`)
All 376,992 five-card hands (19,998 suit classes) have precomputed equity vs a
random hand and vs a top-25% hand (3,000 Monte-Carlo runouts each). Their
blend's percentile is "preflop strength". 1 MB, loaded at startup.

### 3. Opponent range: a Bayesian particle filter (`ranges.py`)
Each hand, ~600 candidate opponent hands are sampled from the unseen cards
(never our cards or the board — no information leakage). Each opponent action
multiplies a particle's weight by P(action | hand strength):

* the opponent's observed fold / call / raise frequencies in that betting
  context (`opponent.py`) define strength *bands*: bluffs at the bottom,
  folds, calls, value raises at the top, with soft logistic edges;
* strength is the particle's percentile **within the opponent's current
  weighted range** on that street (preflop table; made hand + draw outs on
  flop/turn; exact score on the river), so each action narrows the range
  relative to what survived the previous one.

Because the bands come from learned frequencies, the filter adapts on its
own: a calling station's calls carry no information, a nit's bet means a
strong range, a maniac's raises are discounted by his measured bluff share.

Two refinements added in the optimisation round (see below):
* **Detailed statistics.** Frequencies are kept per (context, street, raise
  level) as well as pooled; a detailed bucket is shrunk toward its pooled
  context, `f = (n + k·f_pooled)/(N + k)`, so it only departs from the pooled
  estimate with evidence (flop c-bet folding ≠ river folding ≠ folding to a
  re-raise).
* **Showdown calibration.** At each showdown the bot replays the filter with
  the opponent's shown cards and records, for every opponent action that
  hand, where its real hand ranked in the range being tracked at that moment.
  Those (context, action, strength-bin) counts update `p(strength | action)`
  as Dirichlet counts on top of the band shape, and the likelihoods are
  re-weighted by posterior/prior (Bayes' rule). An opponent who bets weak
  hands and checks strong ones is then modelled as exactly that.

### 4. Decision: expected value per action (`policy.py`)
Equity vs the weighted range comes from Monte-Carlo runouts per particle.
For each legal action:

| action | EV from now (sunk chips ignored) |
|---|---|
| fold | 0 |
| check | `E_r · pot` |
| call | `E_r · (pot + call) − call` (exact all-in / short-stack handling) |
| raise | `P(fold)·pot + (1−P(fold))·(E_c,r · pot_called − chips_added) − reraise_cost` |

`P(fold)` and `E_c` (equity vs the hands that continue) are computed from the
same particles, re-weighted by the opponent's continue-likelihood at that
bet size. Value bets, bluffs and semi-bluffs therefore all come from one
formula: we bluff exactly when fold equity pays for it (never vs a calling
station), value-bet thinner vs stations, and fold more to nits.
`E_r` scales equity by a tuned realisation factor per street/position when
cards remain (1.0 on the river or when all-in). A small softmax temperature
mixes near-equal choices so the bot is not perfectly predictable.

**Adaptive sampling.** If the two best actions are closer than the Monte-Carlo
error (`gap < z · SE`), the decision is re-evaluated with 3× the particles
(topping the pool up with fresh hands that avoid the board). Clear decisions
stay cheap; close ones get the spare time bank, and only while on pace.

### 5. Robustness and time
* everything runs in `try/except`; failures fall back to a cheap rule bot,
  and the answer is always checked against `obs.legal_actions`;
* a **time governor** estimates what the judge charges: per request, our
  compute + server overhead − the 1 ms free grace. The overhead estimate is
  scaled by a contention probe (a fixed 0.2 ms workload re-timed every 50
  decisions), so a slowed-down machine throttles earlier. Above a pace of
  4 s / 1000 hands it uses fewer particles; above 5 s it plays the cheap rule
  bot, so the 8 s bank never runs out;
* numpy first-call costs are paid during startup by a warm-up.

## Training (`training/`)
| script | what it does |
|---|---|
| `build_preflop.py` | builds `sdplo/data/preflop.npz` (≈3 min on 2 cores) |
| `sim.py` | in-process duplicate matches on the official `game.py` (same rules, seat swap, errors, verdict) |
| `opponents.py` | training pool (random, passive, aggressive, tight, equity-based) and held-out pool |
| `tune.py` | cross-entropy-method search over strategy parameters with self-play league |
| `evaluate.py` | tournament-style evaluation on separate `eval-` seeds incl. held-out opponents |
| `timing.py` | thinking time per decision / per 1000 hands |
| `benchmark.py` | A/B benchmark of bot versions on identical deals: paired deltas, VPIP/PFR/AF/F2B/WTSD/all-in %, results by position, latency |
| `exploit.py` | exploitability probe: CEM-trains an 11-parameter adaptive adversary against a fixed version, scores it on fresh seeds |
| `frozen/sdplo_b0/` | frozen copy of the original bot (B0) for comparisons |

```bash
python training/build_preflop.py --samples 3000 --seed 1
python training/tune.py --generations 8 --pop 12 --deals 300 --seed 0   # writes checkpoints/gen_XX.json
cp checkpoints/gen_07.json sdplo/params.json                            # adopt a checkpoint
python training/evaluate.py --deals 1000 --seeds 2 --vs checkpoints/v0_defaults.json

# optimisation-round tools
python training/benchmark.py --bots b0 cur --deals 1000 --seeds 3 --tag mytest   # paired A/B vs B0
python training/benchmark.py --bots cur --opps --h2h b0 --seeds 8               # head-to-head
python training/exploit.py --target cur --tag mine                               # exploitability probe
python training/tune.py --resume sdplo/params.json --ckpt-prefix t3 --generations 6 \
    --pool equity_bot nit maniac calling_station random always_pot tight_passive lag balanced \
    adv:checkpoints/adv_b0.json --keys r_pre_ip r_pre_oop r_post_ip r_post_oop tau
```
`tune.py` resumes from any parameter file (`--resume`, `--start-gen`), writes a
checkpoint per generation and a JSONL log, and is reproducible per `--seed`.

Tuning fitness = Σ over opponents of `3·tanh(z/3)` with `z = mean/SE` of
bb/deal — it rewards turning chops into statistically significant wins
(how the tournament scores) and saturates on opponents already beaten, so the
search cannot trade a loss to a strong bot for a bigger win over a weak one.
All candidates in a generation play the same seeds (common random numbers);
held-out bots and `eval-` seeds are never used in tuning.

## Why this architecture (and not CFR / Deep CFR / NFSP)

| approach | verdict for this event |
|---|---|
| Vanilla CFR | Infeasible: 376,992 hole hands × boards; needs heavy card abstraction. |
| MCCFR + card abstraction | Betting tree is small (4 actions, raise cap 4, 40 bb), but a useful blueprint needs millions of iterations; this was built on 2 CPU cores in pure Python/numpy. Coarse buckets lose exactly the draw/nut information PLO turns on, and an equilibrium blueprint does not *exploit* the weak bots that decide most hackathon matches. |
| Deep CFR / NFSP / self-play RL | Large CPU training budgets, unstable without careful tuning; inference fits the time bank, but there is little reason to expect it to beat an exact-equity model in a hackathon timeframe. |
| **Range-aware EV (chosen)** | Exact hand evaluation and Monte-Carlo equity, Bayesian opponent-range narrowing, explicit pot odds and fold equity, online opponent adaptation, and a handful of parameters tuned by self-play/population matches. Cheap enough for the 8 s bank, adapts to any opponent within a few dozen hands. |

The scoring rule shapes this: a match is won only with a **statistically
significant** edge, and every bot plays every bot once. Reliably beating the
many simple bots (and chopping, not losing, against strong ones) is worth more
than marginal equilibrium accuracy.

## Results of the first version, B0 (measured, not projected)

All matches are full duplicate matches (1,000 deals × 2 halves, seats
swapped), scored like the tournament. In-process results use `training/sim.py`
on `eval-` seeds that tuning never saw. "Held-out" bots were never used in
tuning.

**Tuned parameters (shipped, `sdplo/params.json`), 2 seeds each.** Nit, maniac,
equity bot, TAG and v0 rows are from the final config
(`training/results/eval_final.txt`); the rest from the same parameters before
the time-governor cap was lowered (`eval_gen07.txt`):

| opponent | bb/deal (seed 0 / seed 1) | verdict |
|---|---|---|
| starter (check/fold) | +1.50 / +1.50 | WIN / WIN |
| guide example | +3.28 / +3.30 | WIN / WIN |
| random | +10.60 / +7.50 | WIN / WIN |
| calling station | +10.92 / +10.84 | WIN / WIN |
| always half-pot | +13.30 / +13.32 | WIN / WIN |
| always pot | +7.42 / +8.97 | WIN / WIN |
| nit | +2.50 / +3.25 | WIN / WIN |
| maniac | +10.30 / +9.16 | WIN / WIN |
| equity bot (pot-odds vs random hand) | +2.85 / +3.13 | WIN / WIN |
| **TAG (held-out)** | +1.44 / +1.65 | WIN / WIN |
| **sticky (held-out)** | +11.01 / +9.95 | WIN / WIN |
| untuned v0 (previous version) | +0.20 / −0.13 | CHOP / CHOP |

Untuned v0 on the same seeds scored 21.5 / 22 (chop vs TAG on seed 0,
+0.81 bb/deal). Tuning's gain is real but small: better results vs the
held-out TAG bot, and a statistical tie head-to-head with v0.

**Over real HTTP with the official `judge_engine.py`** (halves played
separately with fresh servers, seed `http7`):

| opponent | bb/deal | 95% CI | result | judge-charged thinking time per half |
|---|---|---|---|---|
| baseline_random | +9.62 | [+8.09, +11.16] | AGENT1_WIN | 3.13 s / 2.97 s |
| baseline_always_pot | +7.26 | [+5.67, +8.84] | AGENT1_WIN | 2.91 s / 2.61 s |
| baseline_calling_station | +10.53 | [+9.53, +11.52] | AGENT1_WIN | 3.15 s / 3.10 s |
| baseline_always_half | +10.23 | [+8.91, +11.55] | AGENT1_WIN | 3.26 s / 3.37 s |

0 errors in every half. Under deliberate CPU contention (two busy processes on
the 2-core test machine) the governor kept the worst half at 5.88 s of 8 s.

Tests at the time: `test_agent.py` 12/12, `tests/test_sdplo.py` 21/21 (now 31/31).

**Caveat on the HTTP numbers:** PyPI was unreachable in the environment where
this was built, so the HTTP runs used a minimal stand-in for FastAPI/uvicorn.
The strategy code and the judge were the real ones, and the official tests
passed through the stand-in, but **run `python -m pytest -q` and
`./tools/check_build.sh` with the real packages before submitting.** Real
uvicorn is typically faster than the stand-in, so time use should be the same
or lower.

## Optimisation round: B0 → B1 (measured)

**Method.** The original bot was frozen as **B0** (`training/frozen/sdplo_b0`,
`checkpoints/B0_shipped.json`). Every candidate change was implemented behind
a parameter, unit-tested, then benchmarked against B0 **on identical deals
with the same random streams**: an identical bot gives a delta of exactly 0,
so the reported per-opponent deltas measure the change, not luck. Each round
used new seeds; a change was kept only if it helped without significant
regressions, and the winner was confirmed on further fresh seeds.

**Opponent pool** (12 + adversaries): random, calling station, always-pot,
nit, maniac, equity bot, TAG, sticky, tight-passive, loose-aggressive (LAG),
"balanced" (value top 25%, bluff bottom 12%, defends ~P/(P+b)), an **adaptive
exploiter** (tracks our fold-to-bet per street and our stab rate, bluffs
when our fold rate makes it profitable, widens calls vs our aggression), and
CEM-trained adversaries. TAG, sticky and the exploiter were never used for
tuning.

**Baseline weaknesses found, ranked by measured impact**

1. **Exploitable by inverted lines.** An adversary trained against B0 won
   **+1.00 bb/deal [+0.40, +1.60]** on held-out seeds by never value-betting
   when checked to, betting its weak hands, and check-raising strong ones.
   B0 assumed "bets = strong" and could learn at most a 60% bluff share.
2. **Time governor overcharged itself.** It added 0.3 ms per request but
   ignored the judge's 1 ms free grace, so vs high-decision opponents B0
   played ~60% of decisions in reduced-sample mode and ~10% with the rule
   fallback while the judge was charging only ~3–4 s of the 8 s bank.
3. **Coarse opponent statistics.** One fold-to-bet number for flop, turn and
   river and for bets vs raises.
4. **Fixed sample size.** Close decisions got the same Monte-Carlo budget as
   obvious ones.
5. **No trapping.** A check was valued as if the round ended.

**Experiments** (mean paired delta vs B0 over 12–13 opponents, 2–3 seeds × 1,000 deals each)

| change | result | decision |
|---|---|---|
| I1 check-node lookahead (check-call / check-raise EV) | −0.23; significant losses vs equity bot, tight-passive | **rejected** |
| I2 per-street / raise-level stats with shrinkage | +0.17 (round 1), +0.30 (round 2, fresh seeds) | kept |
| I3 adaptive sampling | −0.23 alone (it tripped the governor); +0.38 with I2 once budget-gated | kept |
| I4 showdown calibration | vs B0-trained adversary **−1.65 → +2.09**; but −1.2 vs stations (cost) | kept after I5 |
| I5 correct time accounting (+ cheap, pace-gated calibration) | I2+I3+I4+I5 = **+0.585** (round 3) | kept |
| re-tune of 13 parameters (6 CEM gens, broader pool) | +0.418 vs untuned +0.578 on fresh seeds; regression vs exploiter | **rejected** (overfit) |
| contention-aware overhead estimate | worst judge-charged time under CPU contention 7.40 s → 6.27 s | kept |

**Final, shipped B1 vs B0** (`training/results/bench_final.txt`, fresh seeds, 3 × 1,000 deals per opponent)

| opponent | B0 bb/deal | B1 − B0 (paired, 95%) |
|---|---|---|
| random | +9.07 | **+1.45 ± 1.18** |
| calling station | +11.28 | +0.05 ± 0.37 |
| always pot | +7.94 | +0.27 ± 0.73 |
| nit | +2.38 | **+0.45 ± 0.43** |
| maniac | +11.77 | −0.33 ± 0.82 |
| equity bot | +2.80 | +0.31 ± 0.55 |
| TAG (held-out) | +1.37 | +0.21 ± 0.58 |
| sticky (held-out) | +10.51 | **+0.46 ± 0.37** |
| tight-passive | +1.15 | **+0.50 ± 0.36** |
| LAG | +0.61 | **+0.94 ± 0.67** |
| balanced | +0.61 | +0.41 ± 0.55 |
| exploiter (held-out, adaptive) | +1.56 | −0.08 ± 0.58 |
| adversary trained vs B0 | −0.92 | **+2.68 ± 0.64** |
| adversary trained vs B1 | −0.16 | **+0.84 ± 0.61** |

Match points (one match per opponent per seed): **B1 39.5 / 42, B0 35.5 / 42**.
Mean paired delta **+0.58 bb/deal**, reproduced on three independent seed
sets (+0.585, +0.578, +0.584). Head-to-head over 8,000 duplicate deals:
**B1 beats B0 by +0.73 bb/deal [+0.40, +1.07]**.

**Exploitability proxy** (same search budget for both): the best adversary
the CEM search found wins **+1.00 bb/deal [+0.40, +1.60] vs B0** but
**−0.32 bb/deal [−0.90, +0.27] vs B1** — no profitable counter-strategy found.
This is a lower bound on exploitability within one parametric strategy
family, not a full best response.

**Behaviour** (B1, mean over seeds; full table in `bench_final.txt`): VPIP
0.61–0.96 (widest vs always-pot/maniac, ~0.7 vs thinking bots), PFR 0.03 vs
maniac → 0.70 vs tight-passive, fold-to-bet 0.00 vs station → 0.41 vs
tight-passive, WTSD 0.19 vs nit → 1.00 vs station. Mean decision latency
1.0–2.0 ms, p99 ≤ 5.3 ms, max 12.9 ms.

**Through the real judge over HTTP** (B1, 1,000-deal matches, halves on fresh
servers): calling station +12.37, always-half +11.85 (earlier B1 runs:
+11.90 / +13.79 / random +10.08 / always-pot +7.69), all AGENT1_WIN, 0 errors.
Judge-charged thinking 2.95–3.28 s of 8 s per half; **6.27 s worst case**
with two CPU-burning processes competing on the 2-core test machine.

## Key strategic decisions
* **Exploit through measured frequencies, not hard-coded styles.** The same
  code bluffs a folder, never bluffs a station, and folds to a nit's bets,
  because fold equity and range narrowing both come from what this opponent
  has actually done this half.
* **Equity vs the range that continues.** Value bets are sized by equity
  against hands that call, not against all hands.
* **Realised equity, not raw equity, when cards remain.** Out of position and
  preflop, hands realise less than their all-in equity; the factors were tuned.
* **Robustness first.** Three fallback layers, a time governor, warm-up at
  startup, and an always-legal guard: a forfeit costs the whole match.
* **Learn from showdowns what an opponent's actions mean.** Frequencies say
  how often they bet; showdowns say *with what*. Combining the two is what
  closed the exploit found in B0.
* **Randomisation comes from uncertainty, not noise.** Close decisions mix
  because the Monte-Carlo estimate of their EVs varies from sample to sample
  (plus a small softmax); clear decisions are deterministic. Re-tuning chose
  a near-zero extra temperature, and the exploit probe found no profitable
  counter-strategy, so no further artificial mixing was added.

## Known limitations and future work
* **One-step lookahead.** EVs assume the hand is decided after the current
  bet (re-raises only enter as a penalty). A small river/turn subgame solver
  would improve multi-street play, especially vs strong bots.
* **Strength vs unseen strong bots is unknown.** The pool now includes
  adaptive and trained adversaries, but other teams' bots may be stronger in
  ways this pool doesn't cover.
* **Exploitability is only bounded within one strategy family.** The probe
  searches 11 knobs of a heuristic adversary; a learned (e.g. CFR or RL)
  best response could find leaks it cannot.
* **Showdown calibration has selection bias.** Only hands that reach
  showdown are seen; folds never are. Shrinkage toward the band prior limits
  the damage.
* **Draw strength is approximate.** Outs are counted by rank/suit heuristics
  (no nut-draw distinction, no blockers).
* **Opponent model resets every half** (tournament rule) and starts from
  priors; the first ~50 hands are played closer to the prior model.
* **Parameter tuning has hit its noise floor.** The second re-tune overfit
  (better on training seeds, worse on fresh ones) and was rejected; more
  gains need structural changes rather than more tuning on 2 cores.
* **Check-node lookahead didn't pay off as implemented.** A proper
  multi-street subgame search (e.g. depth-limited on the turn/river) is the
  most promising next step for trapping and thin value.
