"""
bot.py - the bot: glue between the judge's interface and the strategy.

    state = BotState(params, seed)       # one per half (kept in `memory`)
    action = state.choose_action(obs)    # always a legal Action
    state.on_hand_end(result)

Safety layers (a forfeit loses the whole match, so robustness comes first):
  1. the full strategy runs inside try/except;
  2. on any exception, or when the time bank is low, a cheap rule-based
     fallback decides;
  3. whatever comes out is checked against obs.legal_actions, and replaced by
     CHECK_CALL (always legal) if needed.
"""

from __future__ import annotations

import time
import traceback
from dataclasses import dataclass

import numpy as np

from game import Action, Street

from . import fasteval as fe
from .history import (POST_UNOPENED, POST_VS_BET, PRE_OPEN, PRE_VS_RAISE, RAISE_O, Event,
                      parse, FOLD_O, CALL_O)
from .opponent import OpponentModel
from .policy import action_evs, cheap_action, choose
from .ranges import HandRange, weighted_percentile


@dataclass(frozen=True)
class _MyAction:
    """Our own action in the same shape as game.ObservedAction."""
    street: Street
    is_me: bool
    action: Action
    amount: int
    street_total: int


def _my_observed_action(obs, action: Action) -> _MyAction:
    if action == Action.FOLD:
        amount = 0
    elif action == Action.CHECK_CALL:
        amount = min(obs.to_call, obs.my_stack)
    else:
        amount = obs.raise_to.get(action, obs.my_bet) - obs.my_bet
    return _MyAction(obs.street, True, action, amount, obs.my_bet + amount)


class BotState:
    def __init__(self, params: dict, seed: int = 0, num_hands: int = 1000) -> None:
        self.p = params
        self.rng = np.random.default_rng(seed)
        self.model = OpponentModel(prior_strength=params["prior_strength"],
                                   detail=bool(params.get("ctx_detail", 0)), shrink=params.get("child_shrink", 12.0),
                                   calib=bool(params.get("calib", 0)), sd_prior=params.get("sd_prior", 20.0))
        self.num_hands = max(1, num_hands)
        self.cur_hand = -1
        self.hrange: HandRange | None = None
        self.last_obs = None
        self.last_action: Action | None = None
        self.time_used = 0.0
        self.decisions = 0
        self.fallbacks = 0
        self.escalations = 0
        self.errors: list[str] = []
        # Contention probe: a small fixed workload, timed now and every 50
        # decisions.  slow = current time / fastest time seen; it scales the
        # per-request server overhead we cannot time ourselves.
        prng = np.random.default_rng(12345)
        cards = np.argsort(prng.random((200, 36)), axis=1)[:, :10]
        self._probe_h, self._probe_b = cards[:, :5].copy(), cards[:, 5:].copy()
        self.slow = 1.0
        self._probe_ref = min(self._probe() for _ in range(3))

    # ------------------------------------------------------------------ act
    def choose_action(self, obs) -> Action:
        t0 = time.perf_counter()
        action = None
        try:
            if obs.hand_index != self.cur_hand:
                self.cur_hand = obs.hand_index
                self.hrange = None
            mode = self._budget_mode(obs.hand_index)
            if mode == "cheap":
                self.fallbacks += 1
                action = cheap_action(obs)
            else:
                action = self._strategy(obs, mode)
        except Exception:  # never let a bug reach the judge
            if len(self.errors) < 20:
                self.errors.append(traceback.format_exc())
            try:
                self.fallbacks += 1
                action = cheap_action(obs)
            except Exception:
                action = None
        if action not in obs.legal_actions:
            action = Action.CHECK_CALL
        self.last_obs, self.last_action = obs, action
        self.decisions += 1
        # What the judge charges for this request: our compute plus server /
        # network overhead, minus the free grace period every request gets.
        if self.decisions % 50 == 0:
            t = min(self._probe(), self._probe())
            self._probe_ref = min(self._probe_ref, t)
            self.slow = float(np.clip(0.6 * self.slow + 0.4 * t / max(self._probe_ref, 1e-9), 1.0, 5.0))
        dt = time.perf_counter() - t0
        self.time_used += max(0.0, dt + (self.p["overhead_ms"] * self.slow - self.p["grace_ms"]) / 1000.0)
        return action

    def _probe(self) -> float:
        t0 = time.perf_counter()
        fe.omaha_scores(self._probe_h, self._probe_b)
        return time.perf_counter() - t0

    def _budget_mode(self, hand_index: int) -> str:
        if self.time_used > self.p["hard_seconds"]:
            return "cheap"
        allowance = self.p["target_seconds"] * (hand_index + 1) / self.num_hands
        if self.time_used > 1.25 * allowance + 0.3:
            return "lean"
        return "full"

    def _strategy(self, obs, mode: str) -> Action:
        p = self.p
        if self.hrange is None:
            self.hrange = HandRange(obs.hole_cards, self.rng, int(p["pool_size"]))
        hr = self.hrange
        n = int(p["n_particles_pre"] if obs.street == Street.PREFLOP else p["n_particles"])
        if mode != "full":
            n = max(60, n // 3)
        runouts = int(p["runouts_flop"]) if (obs.street == Street.FLOP and mode == "full") else 1
        board = tuple(obs.board)
        idx = hr.valid_indices(board, n)
        if len(idx) < 20:
            return cheap_action(obs)
        opp_events = [e for e in parse(obs.action_history, obs.is_button) if not e.is_me]
        evs, n_eff = self._evaluate(obs, hr, board, idx, runouts, opp_events)
        # Adaptive sampling: if the two best actions are closer than the Monte
        # Carlo error, re-evaluate with more particles (only when on pace).
        mult = int(p.get("adaptive_mult", 0))
        allowance = p["target_seconds"] * (obs.hand_index + 1) / self.num_hands
        if mult > 1 and mode == "full" and len(evs) > 1 and self.time_used < p["adaptive_budget"] * allowance:
            top = sorted(evs.values(), reverse=True)
            stake = obs.pot + 2 * obs.to_call
            se = stake * 0.5 / np.sqrt(max(1.0, n_eff))          # SE of an equity-scaled EV
            if top[0] - top[1] < p["adaptive_z"] * se:
                idx2 = hr.valid_indices(board, n * mult, top_up=True)
                if len(idx2) > len(idx):
                    self.escalations += 1
                    evs, _ = self._evaluate(obs, hr, board, idx2, runouts, opp_events)
        return choose(evs, p, obs.big_blind, self.rng)

    def _evaluate(self, obs, hr, board, idx, runouts, opp_events):
        p = self.p
        w = hr.weights(opp_events, board, idx, self.model, p)
        res, owner = hr.showdown_results(board, idx, runouts)
        wr = w[owner]
        s_cur = hr.street_strength(int(obs.street), board, idx, p["draw_weight"])
        x_cur = weighted_percentile(s_cur, w)[owner]
        evs, _E = action_evs(obs, res, wr, x_cur, self.model, p)
        n_eff = float(wr.sum() ** 2 / max(1e-12, (wr ** 2).sum()))
        return evs, n_eff

    # ------------------------------------------------------------- learning
    def on_hand_end(self, result) -> None:
        t0 = time.perf_counter()
        try:
            self._learn(result)
        except Exception:
            if len(self.errors) < 20:
                self.errors.append(traceback.format_exc())
        finally:
            self.model.hands += 1
            self.time_used += time.perf_counter() - t0   # the judge times this too
            self.hrange = None
            self.last_obs = None
            self.last_action = None

    def _record_showdown(self, result, events) -> None:
        """Replay the filter over this hand with the opponent's shown cards:
        for each of its actions, where did its real hand rank within the
        range we were tracking at that moment?  (Feeds model.likelihoods.)"""
        hr = self.hrange
        if hr is None:
            return
        p = self.p
        allowance = p["target_seconds"] * (result.hand_index + 1) / self.num_hands
        if self.time_used > allowance:      # behind pace: skip (calibration is optional)
            return
        board = np.asarray(result.board, dtype=np.int64)
        idx = hr.valid_indices(board, int(p["calib_particles"]))
        if len(idx) < 40:
            return
        opp = np.asarray(result.opp_hole, dtype=np.int64)
        hands = np.concatenate([hr.pool[idx], opp[None, :]])
        w = np.ones(len(idx))
        strength = {}
        for ev in events:
            st = int(ev.street)
            if st not in strength:
                if st == 0:
                    from .tables import PRE_PCT
                    strength[st] = PRE_PCT[fe.hand_index(hands)].astype(np.float64)
                else:
                    nb = {1: 3, 2: 4, 3: 5}[st]
                    strength[st] = hr._compute_strength(hands, board[:nb], p["draw_weight"])
            s_all = strength[st]
            s, s_o = s_all[:-1], s_all[-1]
            x_o = (w[s < s_o].sum() + 0.5 * w[s == s_o].sum()) / w.sum()
            self.model.observe_shown(ev.context, ev.outcome, float(x_o))
            x = weighted_percentile(s, w)
            lik = self.model.likelihoods(x, self.model.freqs(ev.context, ev.street, ev.level),
                                         ev.context, p["tau"])[ev.outcome]
            w = w * np.maximum(lik, p["lik_floor"])
            w /= w.mean()

    def _learn(self, result) -> None:
        obs, act = self.last_obs, self.last_action
        if obs is None or obs.hand_index != result.hand_index:
            # We never acted: we were the big blind and the button folded.
            if not result.went_to_showdown and result.winner == "me":
                self.model.observe(PRE_OPEN, FOLD_O)
            return
        history = list(obs.action_history) + [_my_observed_action(obs, act)]
        events = [e for e in parse(history, obs.is_button) if not e.is_me]
        # Infer the opponent's final, unseen action.
        raised = act in (Action.RAISE_HALF, Action.RAISE_POT)
        resp_ctx = PRE_VS_RAISE if obs.street == Street.PREFLOP else POST_VS_BET
        lvl = obs.raises_this_street + 1
        if raised and not result.went_to_showdown and result.winner == "me":
            events.append(Event(int(obs.street), False, FOLD_O, resp_ctx, 0, 0, lvl))
        elif raised and result.went_to_showdown:
            events.append(Event(int(obs.street), False, CALL_O, resp_ctx, 0, 0, lvl))
        elif (act == Action.CHECK_CALL and obs.to_call == 0 and result.went_to_showdown
              and obs.street == Street.RIVER and not obs.is_button):
            events.append(Event(int(Street.RIVER), False, CALL_O, POST_UNOPENED, 0, 0, 0))
        for e in events:
            self.model.observe(e.context, e.outcome, e.street, e.level)
        if self.model.calib and result.went_to_showdown and result.opp_hole is not None:
            self._record_showdown(result, events)
        # Showdown after the opponent was aggressive: was it a weak hand?
        if result.went_to_showdown and result.opp_hole is not None:
            aggr = [e.street for e in events if e.outcome == RAISE_O]
            if aggr:
                pct = showdown_percentile(result.opp_hole, result.board, aggr[-1], self.rng,
                                          self.p["draw_weight"])
                self.model.observe_showdown_aggression(pct)


def showdown_percentile(opp_hole, board, street: int, rng, draw_weight: float, n: int = 300) -> float:
    """Percentile of the opponent's hand among random hands, measured on the
    street of its last aggressive action (board cards known by then only)."""
    nb = {0: 0, 1: 3, 2: 4, 3: 5}[int(street)]
    vis = np.asarray(board[:nb], dtype=np.int64)
    opp = np.asarray(opp_hole, dtype=np.int64)
    if nb == 0:
        from .tables import PRE_PCT
        return float(PRE_PCT[fe.hand_index(opp)])
    hr = HandRange(opp, rng, n)                 # random hands that avoid the opponent's cards
    idx = hr.valid_indices(vis, n)
    hands = np.concatenate([hr.pool[idx], opp[None, :]])
    s = hr._compute_strength(hands, vis, draw_weight)
    return float((s[:-1] < s[-1]).mean() + 0.5 * (s[:-1] == s[-1]).mean())
