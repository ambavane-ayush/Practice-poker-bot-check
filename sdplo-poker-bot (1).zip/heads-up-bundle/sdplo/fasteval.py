"""
fasteval.py - vectorised (numpy) Short Deck PLO5 hand evaluation.

Why: evaluator.omaha_score does 100 dict lookups in pure Python per hand
(~25-40 us).  Monte-Carlo equity needs thousands of evaluations per decision,
so we evaluate whole batches at once with numpy instead.

Trick: a five-card hand's score depends only on the multiset of its ranks and
on whether all five cards share a suit.  Both can be encoded ADDITIVELY:

    rank key  = sum(5 ** rank(c))   (each rank appears <= 4 times, so base 5 is
                                     a unique encoding; max key < 5**9)
    suit key  = sum(8 ** suit(c))   (each suit appears <= 5 times, so base 8)

A 2-card hole pair and a 3-card board triple therefore combine by plain
addition of their partial keys, which numpy broadcasts for free:
(N, 10 pairs, 1) + (N, 1, 10 triples) -> (N, 10, 10) five-card keys, then one
table gather and a max give the Omaha (exactly 2 + 3) score of N hands.

Scores are produced with evaluator._score_ranks, i.e. the official rules, and
tests/test_engine.py checks equality with evaluator.omaha_score.
"""

from __future__ import annotations

from itertools import combinations, combinations_with_replacement
from math import comb

import numpy as np

from evaluator import NUM_CARDS, _score_ranks

# ---------------------------------------------------------------------------
# Per-card partial keys
# ---------------------------------------------------------------------------
RANK_KEY_SIZE = 5 ** 9
CARD_RANK = np.arange(NUM_CARDS, dtype=np.int64) >> 2
CARD_SUIT = np.arange(NUM_CARDS, dtype=np.int64) & 3
CARD_RKEY = (5 ** CARD_RANK).astype(np.int32)      # 5^rank
CARD_SKEY = (8 ** CARD_SUIT).astype(np.int32)      # 8^suit

PAIRS_IDX = np.array(list(combinations(range(5), 2)), dtype=np.int64)    # (10, 2)
TRIPLES_IDX = np.array(list(combinations(range(5), 3)), dtype=np.int64)  # (10, 3)
TRIPLES4_IDX = np.array(list(combinations(range(4), 3)), dtype=np.int64)  # (4, 3) for turn boards


def _build_tables() -> tuple[np.ndarray, np.ndarray]:
    """SCORE[rank_key + flush * RANK_KEY_SIZE] and FLUSH_FLAG[suit_key]."""
    score = np.zeros(2 * RANK_KEY_SIZE, dtype=np.int32)
    for ranks in combinations_with_replacement(range(9), 5):
        if max(ranks.count(r) for r in set(ranks)) > 4:
            continue  # five of a kind is impossible
        key = sum(5 ** r for r in ranks)
        desc = tuple(sorted(ranks, reverse=True))
        score[key] = _score_ranks(desc, False)
        if len(set(ranks)) == 5:
            score[RANK_KEY_SIZE + key] = _score_ranks(desc, True)
    flag = np.zeros(8 ** 4 * 2, dtype=np.int32)
    for s in range(4):
        flag[5 * 8 ** s] = RANK_KEY_SIZE  # five cards of suit s -> offset into flush half
    return score, flag


SCORE_TABLE, FLUSH_OFFSET = _build_tables()

# ---------------------------------------------------------------------------
# Combinatorial index of a 5-card hand (0 .. C(36,5)-1), used by lookup tables
# ---------------------------------------------------------------------------
_BINOM = np.array([[comb(n, k) for k in range(6)] for n in range(NUM_CARDS + 1)], dtype=np.int64)
NUM_HANDS5 = int(_BINOM[NUM_CARDS, 5])  # 376,992


def hand_index(hands: np.ndarray) -> np.ndarray:
    """Combinatorial-number-system index of 5-card hands, shape (..., 5).
    Cards need not be sorted."""
    h = np.sort(np.asarray(hands, dtype=np.int64), axis=-1)
    return (_BINOM[h[..., 0], 1] + _BINOM[h[..., 1], 2] + _BINOM[h[..., 2], 3]
            + _BINOM[h[..., 3], 4] + _BINOM[h[..., 4], 5])


def all_hands() -> np.ndarray:
    """Every 5-card hand, ordered so that row i has hand_index == i."""
    combos = np.array(list(combinations(range(NUM_CARDS), 5)), dtype=np.int8)
    out = np.empty_like(combos)
    out[hand_index(combos)] = combos
    return out


# ---------------------------------------------------------------------------
# Partial keys and batch scoring
# ---------------------------------------------------------------------------

def pair_keys(holes: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    """Rank/suit partial keys of the 10 hole pairs. holes: (..., 5) -> (..., 10)."""
    pc = holes[..., PAIRS_IDX]                      # (..., 10, 2)
    return CARD_RKEY[pc].sum(-1, dtype=np.int32), CARD_SKEY[pc].sum(-1, dtype=np.int32)


def triple_keys(boards: np.ndarray, triples: np.ndarray = TRIPLES_IDX) -> tuple[np.ndarray, np.ndarray]:
    """Rank/suit partial keys of board triples. boards: (..., B) -> (..., T)."""
    tc = boards[..., triples]                       # (..., T, 3)
    return CARD_RKEY[tc].sum(-1, dtype=np.int32), CARD_SKEY[tc].sum(-1, dtype=np.int32)


def combine_max(prk, psk, trk, tsk) -> np.ndarray:
    """Best score over all pair x triple combinations.
    prk/psk: (..., 10) pair keys; trk/tsk: (..., T) triple keys (broadcastable)."""
    rk = prk[..., :, None] + trk[..., None, :]
    sk = psk[..., :, None] + tsk[..., None, :]
    return SCORE_TABLE[rk + FLUSH_OFFSET[sk]].max(axis=(-1, -2))


def omaha_scores(holes: np.ndarray, boards: np.ndarray) -> np.ndarray:
    """Vectorised omaha_score. holes (N, 5), boards (N, 5) or (5,) -> (N,)."""
    holes = np.asarray(holes, dtype=np.int64)
    boards = np.asarray(boards, dtype=np.int64)
    prk, psk = pair_keys(holes)
    trk, tsk = triple_keys(boards)
    return combine_max(prk, psk, trk, tsk)


def made_scores(holes: np.ndarray, board: np.ndarray) -> np.ndarray:
    """Best made hand right now (exactly 2 hole + 3 of the visible board cards)
    for a 3- or 4-card board. holes (N, 5), board (3,) or (4,) -> (N,)."""
    holes = np.asarray(holes, dtype=np.int64)
    board = np.asarray(board, dtype=np.int64)
    prk, psk = pair_keys(holes)
    if len(board) == 3:
        trk = np.array([CARD_RKEY[board].sum()])
        tsk = np.array([CARD_SKEY[board].sum()])
    elif len(board) == 4:
        trk, tsk = triple_keys(board, TRIPLES4_IDX)
    else:
        trk, tsk = triple_keys(board)
    return combine_max(prk, psk, trk, tsk)
