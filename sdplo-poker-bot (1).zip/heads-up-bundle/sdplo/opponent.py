"""
opponent.py - online opponent model (lives in `memory`, reset every half).

For each betting context (see history.py) we count how often the opponent
folds, checks/calls and raises, starting from prior pseudo-counts so early
estimates are sensible.  We also estimate the share of the opponent's raises
that are "bluffs" (weak hands) from showdowns.

These frequencies drive two things:
  * ranges.py turns them into likelihoods P(action | hand strength) and
    narrows the opponent's range with Bayes' rule;
  * policy.py uses the fold frequency as fold equity when we bet.
"""

from __future__ import annotations

import numpy as np

from .history import (CALL_O, FOLD_O, POST_UNOPENED, POST_VS_BET, PRE_OPEN, PRE_UNOPENED,
                      PRE_VS_RAISE, RAISE_O)
from .ranges import band_likelihoods

N_BINS = 5
_GRID = (np.arange(200) + 0.5) / 200.0
_GRID_BIN = np.minimum((_GRID * N_BINS).astype(int), N_BINS - 1)


def strength_bin(x):
    return np.minimum((np.asarray(x) * N_BINS).astype(int), N_BINS - 1)

# Prior (fold, call, raise) frequencies per context.
PRIORS = {
    PRE_OPEN: (0.25, 0.35, 0.40),
    PRE_UNOPENED: (0.00, 0.65, 0.35),
    PRE_VS_RAISE: (0.30, 0.50, 0.20),
    POST_UNOPENED: (0.00, 0.55, 0.45),
    POST_VS_BET: (0.40, 0.45, 0.15),
}


class OpponentModel:
    """detail=True adds child buckets per (context, street, raise level).  A
    child's frequency is shrunk toward its parent context:

        f_child = (n_child + k * f_parent) / (N_child + k)

    so a bucket with few observations behaves like the pooled estimate and
    only moves away from it with evidence (k = `shrink`)."""

    def __init__(self, prior_strength: float = 15.0, bluff_prior: float = 0.15,
                 bluff_prior_strength: float = 8.0, detail: bool = False, shrink: float = 12.0,
                 calib: bool = False, sd_prior: float = 20.0) -> None:
        self.detail = detail
        self.calib = calib
        self.sd_prior = sd_prior
        self.sd: dict = {}            # (context, outcome) -> counts of shown strength bins
        self.shrink = shrink
        self.child: dict = {}
        self.counts = {c: np.array(p, dtype=float) * prior_strength for c, p in PRIORS.items()}
        self.raw = {c: np.zeros(3) for c in PRIORS}           # observed only (for reports)
        self.bluffs = bluff_prior * bluff_prior_strength      # weak hands shown after aggression
        self.shown_aggr = bluff_prior_strength                 # aggressive lines shown down
        self.hands = 0

    # ----- updates -----------------------------------------------------------
    @staticmethod
    def _key(context: int, street, level):
        return (context, int(street), min(int(level or 0), 2))

    def observe(self, context: int, outcome: int, street=None, level=None) -> None:
        self.counts[context][outcome] += 1.0
        self.raw[context][outcome] += 1.0
        if street is not None:
            k = self._key(context, street, level)
            if k not in self.child:
                self.child[k] = np.zeros(3)
            self.child[k][outcome] += 1.0

    def observe_showdown_aggression(self, strength_pct: float, weak_cut: float = 0.35) -> None:
        """Opponent showed down a hand after betting/raising on its last
        aggressive street; strength_pct is that hand's percentile (0..1)."""
        self.shown_aggr += 1.0
        if strength_pct < weak_cut:
            self.bluffs += 1.0

    def observe_shown(self, context: int, outcome: int, x: float) -> None:
        """At a showdown: the opponent took `outcome` in `context` holding a
        hand at percentile x of the range we were tracking at that moment."""
        k = (context, outcome)
        if k not in self.sd:
            self.sd[k] = np.zeros(N_BINS)
        self.sd[k][int(strength_bin(x))] += 1.0

    # ----- queries -----------------------------------------------------------
    def likelihoods(self, x: np.ndarray, freqs, context: int, tau: float):
        """P(fold | x), P(call | x), P(raise | x) for strength percentiles x.

        Prior shape: the band model (bluffs low, folds, calls, value raises
        high).  With calibration on, showdowns update p(strength bin | action)
        as Dirichlet counts on top of the band-implied bin masses (prior
        weight sd_prior), and the band likelihoods are multiplied by
        posterior / prior per bin and renormalised - Bayes' rule
        P(a | x) ~ f_a p(x | a).  An opponent who bets weak hands and checks
        strong ones is then modelled as such once the evidence is there."""
        L = band_likelihoods(x, freqs, self.bluff_share(), tau)
        if not self.calib or not self.sd:
            return L
        Lg = band_likelihoods(_GRID, freqs, self.bluff_share(), tau)
        b = strength_bin(x)
        out = []
        changed = False
        for a in range(3):
            n = self.sd.get((context, a))
            if n is None or n.sum() == 0 or Lg[a].sum() < 1e-9:
                out.append(L[a])
                continue
            m = np.bincount(_GRID_BIN, weights=Lg[a], minlength=N_BINS) / Lg[a].sum()
            post = (n + self.sd_prior * m) / (n.sum() + self.sd_prior)
            ratio = post / np.maximum(m, 1e-6)
            out.append(L[a] * ratio[b])
            changed = True
        if not changed:
            return L
        tot = np.maximum(out[0] + out[1] + out[2], 1e-12)
        return out[0] / tot, out[1] / tot, out[2] / tot
    def freqs(self, context: int, street=None, level=None) -> tuple[float, float, float]:
        c = self.counts[context]
        f = c / c.sum()
        if self.detail and street is not None:
            n = self.child.get(self._key(context, street, level))
            if n is not None:
                f = (n + self.shrink * f) / (n.sum() + self.shrink)
        if context in (PRE_UNOPENED, POST_UNOPENED):
            f = np.array([0.0, f[1] + f[0], f[2]])  # no folding when checking is free
        return float(f[0]), float(f[1]), float(f[2])

    def bluff_share(self) -> float:
        return float(np.clip(self.bluffs / self.shown_aggr, 0.02, 0.6))

    def fold_to_bet(self, preflop: bool) -> float:
        return self.freqs(PRE_VS_RAISE if preflop else POST_VS_BET)[FOLD_O]

    def summary(self) -> dict:
        return {
            "hands": self.hands,
            "bluff_share": round(self.bluff_share(), 3),
            **{name: [round(x, 3) for x in self.freqs(c)]
               for name, c in (("pre_open", PRE_OPEN), ("pre_unopened", PRE_UNOPENED),
                               ("pre_vs_raise", PRE_VS_RAISE), ("post_unopened", POST_UNOPENED),
                               ("post_vs_bet", POST_VS_BET))},
        }


__all__ = ["OpponentModel", "PRIORS", "FOLD_O", "CALL_O", "RAISE_O"]
