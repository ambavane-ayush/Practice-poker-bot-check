"""
params.py - strategy parameters.

DEFAULTS are hand-set starting values.  training/tune.py searches over the
TUNABLE ones and writes the best set to sdplo/params.json, which the bot
loads if present (missing keys fall back to DEFAULTS).
"""

from __future__ import annotations

import json
import os

DEFAULTS: dict = {
    # realised-equity factors (multiplied into all-in equity when cards remain)
    "r_pre_ip": 0.95,
    "r_pre_oop": 0.85,
    "r_post_ip": 1.0,
    "r_post_oop": 0.9,
    # range model
    "tau": 0.08,            # softness of the likelihood bands
    "lik_floor": 0.03,      # no particle is ever ruled out completely
    "draw_weight": 0.7,     # how much draws count toward flop/turn strength
    "prior_strength": 15.0, # pseudo-counts behind the opponent-model priors
    # betting
    "fold_adj_pot": 0.04,   # extra folds we expect to a pot-size raise
    "fold_adj_half": -0.04, # fewer folds to a half-pot raise
    "reraise_cost": 0.3,    # penalty (x chips added) when re-raised
    "temperature": 0.05,    # softmax temperature in big blinds (0 = greedy)
    "lookahead": 0,         # 1 = value an out-of-position check with one step of lookahead (tested: worse, off)
    "opp_bet_frac": 0.75,   # opponent bet size (x pot) assumed in that lookahead
    "ctx_detail": 1,        # 1 = opponent stats per (context, street, raise level), shrunk to pooled
    "child_shrink": 12.0,   # pseudo-count pulling a detailed bucket toward its pooled context
    "adaptive_mult": 3,     # >1: re-evaluate close decisions with this many times the particles
    "adaptive_z": 1.0,      # "close" = EV gap of the top two actions < z * Monte-Carlo SE
    "adaptive_budget": 0.85,  # only escalate while thinking time < this share of the pace
    "calib": 1,             # 1 = calibrate action likelihoods from showdowns
    "sd_prior": 20.0,       # prior weight of the band shape in that calibration
    "calib_particles": 90,  # particles used to replay a showdown hand
    # compute budget
    "n_particles": 150,     # particles evaluated per postflop decision
    "n_particles_pre": 110, # particles evaluated per preflop decision
    "pool_size": 600,       # particles drawn per hand
    "runouts_flop": 1,      # random runouts per particle on the flop
    "target_seconds": 4.0,  # aim to use at most this much thinking time per half
    "hard_seconds": 5.0,    # beyond this, only the cheap fallback is used
    "overhead_ms": 0.8,     # assumed per-request server + network overhead (not timed by us)
    "grace_ms": 1.0,        # free time per request the judge does not charge (game.py: 1 ms)
}

TUNABLE = {
    # name: (low, high)
    "r_pre_ip": (0.75, 1.1),
    "r_pre_oop": (0.65, 1.0),
    "r_post_ip": (0.8, 1.15),
    "r_post_oop": (0.7, 1.05),
    "tau": (0.03, 0.2),
    "draw_weight": (0.2, 1.0),
    "fold_adj_pot": (-0.05, 0.15),
    "fold_adj_half": (-0.15, 0.05),
    "reraise_cost": (0.0, 0.8),
    "temperature": (0.0, 0.3),
    "prior_strength": (4.0, 40.0),
    "child_shrink": (3.0, 40.0),
    "sd_prior": (5.0, 60.0),
    "adaptive_z": (0.3, 2.0),
}

PARAMS_PATH = os.path.join(os.path.dirname(__file__), "params.json")


def load_params(path: str = PARAMS_PATH) -> dict:
    p = dict(DEFAULTS)
    try:
        with open(path) as f:
            stored = json.load(f)
        for k, v in stored.items():
            if k in DEFAULTS and isinstance(v, (int, float)):
                p[k] = type(DEFAULTS[k])(v)
    except (OSError, ValueError):
        pass
    return p
