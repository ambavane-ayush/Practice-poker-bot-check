"""
policy.py - turn equity-vs-range into an action by comparing expected values.

For every legal action we estimate the chips we expect to win from this point
on (chips already in the pot are sunk):

    FOLD        0
    CHECK       E_r * pot
    CALL        E_r * (pot after call) - call amount
    RAISE(s)    P(fold) * pot
                + (1 - P(fold)) * (E_c,r * (pot if called) - our chips added)

E is our weighted Monte-Carlo equity against the opponent's estimated range.
E_c is the equity against the part of that range that continues versus our
raise (particles re-weighted by the opponent's continue-likelihood), and
P(fold) comes from the same likelihoods, i.e. from the opponent's observed
fold frequency.  So value bets, bluffs and semi-bluffs all fall out of one
formula: bluffs are chosen exactly when fold equity pays for them, and value
bets when the calling range is weak enough.

E_r = realised equity.  With cards still to come the raw all-in equity
overstates what a hand actually wins (position, future bets), so it is scaled
by a tuned factor per street/position.  When no more betting can happen
(river, or someone all-in) the factor is 1.

A small softmax temperature mixes close decisions so we are not perfectly
predictable.
"""

from __future__ import annotations

import numpy as np

from game import Action, Street

from .history import opp_response_context
from .ranges import band_likelihoods

RAISES = (Action.RAISE_HALF, Action.RAISE_POT)


def realization(p: dict, street: int, in_position: bool) -> float:
    if street == Street.PREFLOP:
        return p["r_pre_ip"] if in_position else p["r_pre_oop"]
    if street == Street.RIVER:
        return 1.0
    return p["r_post_ip"] if in_position else p["r_post_oop"]


def in_position(obs) -> bool:
    """Button acts last after the flop.  Preflop the button acts first, but it
    keeps position for the rest of the hand, so 'in position' = button."""
    return bool(obs.is_button)


def action_evs(obs, res: np.ndarray, wr: np.ndarray, x_r: np.ndarray, model, p: dict) -> dict:
    """Expected chip value of each legal action (chips, from now on)."""
    wsum = wr.sum()
    E = float((wr * res).sum() / wsum)
    ip = in_position(obs)
    R = realization(p, int(obs.street), ip)
    P, C = obs.pot, obs.to_call
    evs: dict[Action, float] = {}
    for a in obs.legal_actions:
        if a == Action.FOLD:
            evs[a] = 0.0
        elif a == Action.CHECK_CALL:
            if C == 0:
                evs[a] = min(1.0, E * R) * P
                if p.get("lookahead", 0) and obs.street != Street.PREFLOP and not ip:
                    evs[a] = check_ev_oop(obs, res, wr, x_r, model, p, R)
            else:
                c_eff = min(C, obs.my_stack)
                pot_after = P - (C - c_eff) + c_eff
                no_more_betting = c_eff == obs.my_stack or obs.opp_stack == 0 or obs.street == Street.RIVER
                r = 1.0 if no_more_betting else R
                evs[a] = min(1.0, E * r) * pot_after - c_eff
        else:
            raise_to = obs.raise_to.get(a)
            if raise_to is None:
                continue
            opp_call = min(raise_to - obs.opp_bet, obs.opp_stack)
            added = C + opp_call                      # our chips that get called
            pot_called = P + added + opp_call
            no_more = (obs.street == Street.RIVER or opp_call == obs.opp_stack
                       or added >= obs.my_stack)
            r = 1.0 if no_more else R
            f = list(model.freqs(opp_response_context(obs), int(obs.street), obs.raises_this_street + 1))
            adj = p["fold_adj_pot"] if a == Action.RAISE_POT else p["fold_adj_half"]
            f_fold = float(np.clip(f[0] + adj, 0.0, 0.95))
            rest = max(1e-9, f[1] + f[2])
            freqs = (f_fold, (1 - f_fold) * f[1] / rest, (1 - f_fold) * f[2] / rest)
            lf, _lc, _lr = model.likelihoods(x_r, freqs, opp_response_context(obs), p["tau"])
            pf = float((wr * lf).sum() / wsum)
            wc = wr * (1.0 - lf)
            E_c = float((wc * res).sum() / max(1e-12, wc.sum()))
            # Being re-raised costs us some of the value we planned on.
            pr = freqs[2] * (1.0 - pf)
            evs[a] = (pf * P + (1.0 - pf) * (min(1.0, E_c * r) * pot_called - added)
                      - p["reraise_cost"] * pr * added)
    return evs, E


def check_ev_oop(obs, res, wr, x_r, model, p, R) -> float:
    """EV of checking when the opponent acts next (we are out of position
    after the flop).  One step of lookahead instead of 'the round ends here':

        EV = P(opp checks) * E_check-range,r * pot
           + P(opp bets)  * max(fold 0, call, check-raise)   vs the BETTING range

    Which particles bet comes from the band model with the opponent's measured
    frequencies when checked to (value at the top, bluffs at the bottom).  The
    check-raise branch applies their fold-to-raise frequency WITHIN the
    betting range.  This is what makes checking strong hands (check-call /
    check-raise traps) correct against aggressive opponents and keeps our
    checking range from being all weak hands."""
    from .history import POST_UNOPENED, POST_VS_BET
    from .ranges import weighted_percentile

    P = obs.pot
    lf_k, lc_k, lb = model.likelihoods(x_r, model.freqs(POST_UNOPENED, int(obs.street), 0), POST_UNOPENED, p["tau"])
    wb, wk = wr * lb, wr * (1.0 - lb)
    p_b = float(wb.sum() / wr.sum())
    E_k = float((wk * res).sum() / max(1e-12, wk.sum()))
    ev_checked_through = min(1.0, E_k * R) * P
    b = int(min(round(p["opp_bet_frac"] * P), obs.opp_stack, obs.my_stack))
    if b <= 0 or p_b < 1e-6:
        return ev_checked_through
    E_b = float((wb * res).sum() / max(1e-12, wb.sum()))
    last = obs.street == Street.RIVER
    # call the bet
    all_in_call = b >= obs.my_stack or b >= obs.opp_stack
    r_call = 1.0 if (last or all_in_call) else R
    ev_call = min(1.0, E_b * r_call) * (P + 2 * b) - b
    # check-raise to pot: raise_to = b + (P + 2b) = P + 3b, capped by stacks
    ev_cr = -1e9
    if not all_in_call:
        raise_to = min(P + 3 * b, obs.my_stack, b + obs.opp_stack)
        opp_more = raise_to - b
        x_b = weighted_percentile(x_r, wb)          # strength within the betting range
        f = model.freqs(POST_VS_BET, int(obs.street), 2)
        lf2, _, _ = model.likelihoods(x_b, f, POST_VS_BET, p["tau"])
        pf2 = float((wb * lf2).sum() / wb.sum())
        wc2 = wb * (1.0 - lf2)
        E_c2 = float((wc2 * res).sum() / max(1e-12, wc2.sum()))
        r_cr = 1.0 if (last or raise_to >= obs.my_stack or opp_more >= obs.opp_stack) else R
        ev_cr = pf2 * (P + b) + (1.0 - pf2) * (min(1.0, E_c2 * r_cr) * (P + 2 * raise_to) - raise_to)
    return (1.0 - p_b) * ev_checked_through + p_b * max(0.0, ev_call, ev_cr)


def choose(evs: dict, p: dict, big_blind: int, rng: np.random.Generator) -> Action:
    acts = list(evs)
    vals = np.array([evs[a] for a in acts]) / big_blind
    t = p["temperature"]
    if t <= 1e-6:
        return acts[int(np.argmax(vals))]
    z = (vals - vals.max()) / t
    probs = np.exp(z)
    probs /= probs.sum()
    return acts[int(rng.choice(len(acts), p=probs))]


# ---------------------------------------------------------------------------
# Cheap fallback (no Monte Carlo): used if the time bank runs low or if the
# main strategy raises an exception.  Always returns a legal action.
# ---------------------------------------------------------------------------

def cheap_action(obs) -> Action:
    from evaluator import FLUSH, STRAIGHT, THREE_OF_A_KIND
    from . import fasteval as fe
    from .tables import preflop_info

    legal = obs.legal_actions
    C, P = obs.to_call, obs.pot
    if obs.street == Street.PREFLOP:
        eq, _, pct = preflop_info(obs.hole_cards)
        strength = pct
    else:
        score = int(fe.made_scores(np.array([obs.hole_cards]), np.array(obs.board))[0])
        cat = score >> 20
        if cat >= FLUSH:
            strength = 0.9
        elif cat >= THREE_OF_A_KIND:
            strength = 0.75
        elif cat >= STRAIGHT:
            strength = 0.6
        elif cat >= 2:          # two pair
            strength = 0.35
        else:
            strength = 0.15
    price = C / (P + C) if C else 0.0
    if strength > 0.85 and Action.RAISE_POT in legal:
        return Action.RAISE_POT
    if strength > 0.7 and Action.RAISE_HALF in legal and C == 0:
        return Action.RAISE_HALF
    if C == 0:
        return Action.CHECK_CALL
    if strength - 0.25 > price or C <= obs.big_blind // 2:
        return Action.CHECK_CALL
    return Action.FOLD if Action.FOLD in legal else Action.CHECK_CALL
