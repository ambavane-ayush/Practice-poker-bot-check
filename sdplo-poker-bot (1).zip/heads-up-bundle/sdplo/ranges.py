"""
ranges.py - opponent range estimation (Bayesian particle filter) and equity.

The opponent's hidden hand is represented by a pool of sampled 5-card hands
("particles") drawn uniformly from the cards we cannot see.  Each particle
carries a weight = P(opponent's observed actions | that hand).  Equity is
then a weighted Monte-Carlo average over particles, each with its own random
board runout.  No hidden information is used: particles are drawn only from
cards that are not in our hand or on the board.

Likelihood model ("band" model).  In a context where the opponent folds /
calls / raises with frequencies (f_fold, f_call, f_raise) - estimated online
by opponent.py - we assume they rank their range by strength percentile x:

    [0, b)                    bluff-raises   (b = f_raise * bluff_share)
    [b, b + f_fold)           folds
    [b + f_fold, 1 - v)       calls / checks
    [1 - v, 1]                value raises   (v = f_raise * (1 - bluff_share))

with logistic edges of width tau.  x is the particle's percentile of
street strength *within the opponent's current (weighted) range*, so the
filter is sequential: each action narrows the range relative to what was
left after the previous action.

Street strength: preflop = precomputed preflop percentile; flop/turn = made
hand percentile plus a draw bonus (flush draws, rank cards that improve to a
straight or better); river = exact hand score.
"""

from __future__ import annotations

import numpy as np

from evaluator import FLUSH, STRAIGHT
from game import Street

from . import fasteval as fe
from .history import FOLD_O, RAISE_O, CALL_O
from .tables import PRE_PCT

ALL_CARDS = np.arange(36)


def _sig(z: np.ndarray) -> np.ndarray:
    return 0.5 + 0.5 * np.tanh(0.5 * z)      # logistic, overflow-free


def band_likelihoods(x: np.ndarray, freqs, bluff_share: float, tau: float):
    """(L_fold, L_call, L_raise) for strength percentiles x."""
    f_fold, _f_call, f_raise = freqs
    b = f_raise * bluff_share
    v = f_raise * (1.0 - bluff_share)
    s1 = _sig((x - b) / tau)
    s2 = _sig((x - (b + f_fold)) / tau)
    s3 = _sig((x - (1.0 - v)) / tau)
    return s1 - s2, s2 - s3, s3 + (1.0 - s1)


def weighted_percentile(values: np.ndarray, w: np.ndarray) -> np.ndarray:
    """Weighted mid-rank percentile of each value (0..1).  Exact ties are
    broken by sample order, which is random, so this stays unbiased."""
    order = np.argsort(values, kind="stable")
    ws = w[order]
    cw = np.cumsum(ws)
    total = cw[-1] if len(cw) and cw[-1] > 0 else 1.0
    out = np.empty(len(values))
    out[order] = (cw - 0.5 * ws) / total
    return out


_RP_R1 = np.repeat(np.arange(9), 9)
_RP_R2 = np.tile(np.arange(9), 9)
_RP_KEY = (5 ** _RP_R1 + 5 ** _RP_R2).astype(np.int64)        # 81 rank pairs
_NEXT_KEY = (5 ** np.arange(9)).astype(np.int64)


def _improve_table(board: np.ndarray) -> np.ndarray:
    """(81, 9) best non-flush hand category for hole rank pair x next card
    rank, using the next card plus two of the visible board cards."""
    br = fe.CARD_RKEY[board].astype(np.int64)
    bp = np.array([br[i] + br[j] for i in range(len(br)) for j in range(i + 1, len(br))])
    keys = _RP_KEY[:, None, None] + _NEXT_KEY[None, :, None] + bp[None, None, :]
    keys = np.minimum(keys, fe.RANK_KEY_SIZE - 1)   # impossible (5-of-a-kind) keys score 0 anyway
    return fe.SCORE_TABLE[keys].max(axis=2) >> 20


def _rank_pair_index(hands: np.ndarray) -> np.ndarray:
    """(n, 10) index 0..80 of each hole pair's ranks."""
    r = fe.CARD_RANK[hands[:, fe.PAIRS_IDX]]
    return r[..., 0] * 9 + r[..., 1]


class HandRange:
    """Particles for ONE hand; created at our first decision of the hand."""

    def __init__(self, hole, rng: np.random.Generator, pool_size: int = 900) -> None:
        self.hole = np.asarray(hole, dtype=np.int64)
        self.rng = rng
        rest = np.setdiff1d(ALL_CARDS, self.hole)
        keys = rng.random((pool_size, len(rest)))
        self.pool = rest[np.argpartition(keys, 5, axis=1)[:, :5]]            # (P, 5)
        self.pool_mask = (np.int64(1) << self.pool).sum(1)
        self.strength = {0: PRE_PCT[fe.hand_index(self.pool)].astype(np.float64)}
        self.hero_prk, self.hero_psk = fe.pair_keys(self.hole)

    # ----- particles consistent with the board --------------------------------
    def valid_indices(self, board, n_max: int, top_up: bool = False) -> np.ndarray:
        """First n_max particles that do not use a board card.  With top_up,
        draw extra particles (uniform over hands avoiding our cards AND the
        board - the same distribution the filtered pool has) when too few
        survive the board."""
        bmask = int(sum(1 << int(c) for c in board))
        idx = np.flatnonzero((self.pool_mask & bmask) == 0)
        if top_up and len(idx) < n_max:
            self._extend(board, n_max - len(idx))
            idx = np.flatnonzero((self.pool_mask & bmask) == 0)
        return idx[:n_max]

    def _extend(self, board, n_new: int) -> None:
        rest = np.setdiff1d(ALL_CARDS, np.concatenate([self.hole, np.asarray(board, dtype=np.int64)]))
        keys = self.rng.random((n_new, len(rest)))
        new = rest[np.argpartition(keys, 5, axis=1)[:, :5]]
        self.pool = np.concatenate([self.pool, new])
        self.pool_mask = np.concatenate([self.pool_mask, (np.int64(1) << new).sum(1)])
        self.strength[0] = np.concatenate([self.strength[0], PRE_PCT[fe.hand_index(new)].astype(np.float64)])
        for st in list(self.strength):
            if st != 0:
                self.strength[st] = np.concatenate([self.strength[st], np.full(n_new, np.nan)])
        self._wcache = None

    # ----- street strength (cached per particle) -------------------------------
    def street_strength(self, street: int, board, idx: np.ndarray, draw_weight: float) -> np.ndarray:
        if street == Street.PREFLOP:
            return self.strength[0][idx]
        cache = self.strength.get(street)
        if cache is None:
            cache = np.full(len(self.pool), np.nan)
            self.strength[street] = cache
        if np.isnan(cache[idx]).any():
            # Made-hand percentiles are relative to the batch they are computed
            # in, so (re)compute the whole requested set together.
            nb = {Street.FLOP: 3, Street.TURN: 4, Street.RIVER: 5}[Street(street)]
            cache[idx] = self._compute_strength(self.pool[idx], np.asarray(board[:nb]), draw_weight)
        return cache[idx]

    def _compute_strength(self, hands: np.ndarray, board: np.ndarray, draw_weight: float) -> np.ndarray:
        made = fe.made_scores(hands, board).astype(np.float64)
        if len(board) == 5:
            return made
        n = len(hands)
        made_cat = (made.astype(np.int64) >> 20)
        # Flush draws.
        hc = np.zeros((n, 4), dtype=np.int64)
        np.add.at(hc, (np.repeat(np.arange(n), 5), (hands & 3).ravel()), 1)
        bc = np.bincount(board & 3, minlength=4)
        fd = (((bc == 2)[None, :]) & (hc >= 2)).any(1) & (made_cat < FLUSH)
        bdfd = (((bc == 1)[None, :]) & (hc >= 2)).any(1) if len(board) == 3 else np.zeros(n, bool)
        # Rank cards that would improve the hand to a straight or better.
        # Only ranks matter for this, so build an (81 hole-rank-pairs x 9 next
        # ranks) table for this board once, then gather per hand.
        cat9 = _improve_table(board)[_rank_pair_index(hands)].max(axis=1)  # (n, 9)
        n_imp = ((cat9 >= STRAIGHT) & (cat9 > made_cat[:, None])).sum(1)
        outs = np.minimum(3.0 * n_imp + 9.0 * fd + 1.5 * bdfd, 20.0)
        to_come = 5 - len(board)
        p_draw = 1.0 - (1.0 - outs / 27.0) ** to_come
        made_pct = weighted_percentile(made, np.ones(n))
        return made_pct + (1.0 - made_pct) * draw_weight * p_draw

    # ----- Bayesian filter -------------------------------------------------------
    def weights(self, opp_events, board, idx, model, p) -> np.ndarray:
        """Particle weights given the opponent's actions this hand.

        Within one street the particle set is the same for every decision, so
        the filter resumes from the last decision instead of starting over."""
        key = (len(board), len(idx), int(idx[0]) if len(idx) else -1)
        cached = getattr(self, "_wcache", None)
        if cached is not None and cached[0] == key and cached[1] <= len(opp_events):
            start, w = cached[1], cached[2].copy()
        else:
            start, w = 0, np.ones(len(idx))
        for ev in opp_events[start:]:
            s = self.street_strength(ev.street, board, idx, p["draw_weight"])
            x = weighted_percentile(s, w)
            lik = model.likelihoods(x, model.freqs(ev.context, ev.street, ev.level), ev.context, p["tau"])[ev.outcome]
            w = w * np.maximum(lik, p["lik_floor"])
            w /= w.mean()
        self._wcache = (key, len(opp_events), w.copy())
        return w

    # ----- equity -----------------------------------------------------------------
    def showdown_results(self, board, idx: np.ndarray, runouts: int = 1) -> tuple[np.ndarray, np.ndarray]:
        """Hero result (1 win, .5 tie, 0 loss) vs each particle on random runouts.
        Returns (results (len(idx)*runouts,), particle index per result)."""
        board = np.asarray(board, dtype=np.int64)
        opp = self.pool[idx]
        if runouts > 1:
            opp = np.repeat(opp, runouts, axis=0)
        n = len(opp)
        k = 5 - len(board)
        if k == 0:
            hero = fe.combine_max(self.hero_prk, self.hero_psk, *fe.triple_keys(board))
            opp_s = fe.omaha_scores(opp, board)
        else:
            keys = self.rng.random((n, 36))
            keys[:, self.hole] += 2.0
            if len(board):
                keys[:, board] += 2.0
            keys[np.arange(n)[:, None], opp] += 2.0
            run = np.argpartition(keys, k - 1, axis=1)[:, :k] if k < 36 else keys
            full = np.concatenate([np.broadcast_to(board, (n, len(board))), run], axis=1)
            trk, tsk = fe.triple_keys(full)
            opp_prk, opp_psk = fe.pair_keys(opp)
            prk = np.concatenate([np.broadcast_to(self.hero_prk, (n, 10)), opp_prk])
            psk = np.concatenate([np.broadcast_to(self.hero_psk, (n, 10)), opp_psk])
            both = fe.combine_max(prk, psk, np.concatenate([trk, trk]), np.concatenate([tsk, tsk]))
            hero, opp_s = both[:n], both[n:]
        res = (hero > opp_s) + 0.5 * (hero == opp_s)
        owner = np.repeat(np.arange(len(idx)), runouts)
        return res.astype(np.float64), owner
