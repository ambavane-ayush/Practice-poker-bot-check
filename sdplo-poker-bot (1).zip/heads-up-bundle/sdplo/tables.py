"""
tables.py - precomputed preflop strength, loaded once at server start.

preflop.npz (built by training/build_preflop.py) holds, for every one of the
376,992 five-card hands (indexed by fasteval.hand_index):
    eq_rand    equity vs a random hand
    eq_strong  equity vs a top-25% hand
PRE_PCT is the percentile (0..1) of the 50/50 blend of the two; it is the
"preflop strength" used to model opponent ranges.
"""

from __future__ import annotations

import os

import numpy as np

from .fasteval import NUM_HANDS5, hand_index

_PATH = os.path.join(os.path.dirname(__file__), "data", "preflop.npz")


def _load():
    data = np.load(_PATH)
    eq_rand = data["eq_rand"].astype(np.float32) / 65535.0
    eq_strong = data["eq_strong"].astype(np.float32) / 65535.0
    assert len(eq_rand) == NUM_HANDS5 and len(eq_strong) == NUM_HANDS5
    blend = 0.5 * eq_rand + 0.5 * eq_strong
    order = np.argsort(blend, kind="stable")
    pct = np.empty(NUM_HANDS5, dtype=np.float32)
    pct[order] = (np.arange(NUM_HANDS5, dtype=np.float32) + 0.5) / NUM_HANDS5
    return eq_rand, eq_strong, pct


EQ_RAND, EQ_STRONG, PRE_PCT = _load()


def preflop_info(hole) -> tuple[float, float, float]:
    """(equity vs random, equity vs strong range, percentile) of one hand."""
    i = int(hand_index(np.asarray(hole)))
    return float(EQ_RAND[i]), float(EQ_STRONG[i]), float(PRE_PCT[i])
