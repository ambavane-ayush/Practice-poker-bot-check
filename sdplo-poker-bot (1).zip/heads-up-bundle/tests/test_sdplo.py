"""
Tests for the sdplo strategy package (no web server needed):

    python -m pytest -q tests/

Covers hand evaluation, preflop tables, history parsing, the range model,
EV / pot-odds maths, bluffing and value decisions, opponent-model learning,
information hygiene, and a legality/timing fuzz over thousands of states.
"""

import os
import random
import sys
import time

import numpy as np
import pytest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
sys.path.insert(0, os.path.join(ROOT, "training"))

from evaluator import cards_from_str, get_table, omaha_score  # noqa: E402
from game import Action, Game, HandResult, Street, make_deal  # noqa: E402
from sdplo import fasteval as fe  # noqa: E402
from sdplo.bot import BotState  # noqa: E402
from sdplo.history import (CALL_O, FOLD_O, POST_UNOPENED, POST_VS_BET, PRE_OPEN, PRE_UNOPENED,  # noqa: E402
                           PRE_VS_RAISE, RAISE_O, parse)
from sdplo.opponent import OpponentModel  # noqa: E402
from sdplo.params import DEFAULTS  # noqa: E402
from sdplo.policy import action_evs, cheap_action  # noqa: E402
from sdplo.ranges import HandRange, band_likelihoods, weighted_percentile  # noqa: E402
from sdplo.tables import preflop_info  # noqa: E402


# ---------------------------------------------------------------- evaluation
def test_vectorised_eval_matches_official():
    rng = random.Random(0)
    holes, boards = [], []
    for _ in range(3000):
        c = rng.sample(range(36), 10)
        holes.append(c[:5])
        boards.append(c[5:])
    fast = fe.omaha_scores(np.array(holes), np.array(boards))
    slow = [omaha_score(h, b) for h, b in zip(holes, boards)]
    assert fast.tolist() == slow


def test_made_scores_partial_boards():
    from itertools import combinations
    table = get_table()
    rng = random.Random(1)
    for i in range(400):
        c = rng.sample(range(36), 9)
        h, b = c[:5], c[5:5 + 3 + i % 2]
        best = max(table[(1 << a) | (1 << d) | sum(1 << x for x in t)]
                   for a, d in combinations(h, 2) for t in combinations(b, 3))
        assert fe.made_scores(np.array([h]), np.array(b))[0] == best


def test_guide_example_omaha_rule():
    # Board Ah Kh Qh Jh 6c with Th 7s 7d 8c 9c is a king-high straight, not a flush.
    s = fe.omaha_scores(np.array([cards_from_str("Th 7s 7d 8c 9c")]), np.array(cards_from_str("Ah Kh Qh Jh 6c")))
    assert s[0] == omaha_score(cards_from_str("Th 7s 7d 8c 9c"), cards_from_str("Ah Kh Qh Jh 6c"))
    assert s[0] >> 20 == 3  # straight


def test_hand_index_is_a_bijection_sample():
    hands = fe.all_hands()
    assert len(hands) == fe.NUM_HANDS5
    idx = fe.hand_index(hands[::997])
    assert np.array_equal(idx, np.arange(0, fe.NUM_HANDS5, 997))


def test_preflop_table_ordering():
    aakk = preflop_info(cards_from_str("As Ah Ks Kh Qd"))
    sixes = preflop_info(cards_from_str("6c 6d 6h 6s 7c"))
    rundown = preflop_info(cards_from_str("Td Jd Qh Ks 9h"))
    assert aakk[2] > 0.95 and sixes[2] < 0.05 and rundown[2] > 0.5
    assert 0.0 < sixes[0] < rundown[0] < aakk[0] < 1.0


# ------------------------------------------------------------------ history
def _play(actions, button=0, seed="h"):
    g = Game(make_deal(seed, 0), button_seat=button)
    for a in actions:
        g.apply(a)
    return g


def test_history_contexts():
    # Button (seat 0) raises pot, BB re-raises, button calls; flop: BB bets, button folds.
    g = _play([Action.RAISE_POT, Action.RAISE_HALF, Action.CHECK_CALL, Action.RAISE_HALF, Action.FOLD])
    ev = parse(g.observation(1).action_history, i_am_button=False)
    assert [(e.is_me, e.context, e.outcome) for e in ev] == [
        (False, PRE_OPEN, RAISE_O), (True, PRE_VS_RAISE, RAISE_O), (False, PRE_VS_RAISE, CALL_O),
        (True, POST_UNOPENED, RAISE_O), (False, POST_VS_BET, FOLD_O)]
    # Limp then check: big blind is "unopened".
    g = _play([Action.CHECK_CALL])
    obs = g.observation(1)
    assert obs.to_call == 0 and not obs.is_button


# --------------------------------------------------------------- range model
def test_band_likelihoods_are_probabilities():
    x = np.linspace(0, 1, 101)
    for freqs in [(0.3, 0.5, 0.2), (0.0, 0.6, 0.4), (0.9, 0.05, 0.05)]:
        lf, lc, lr = band_likelihoods(x, freqs, 0.2, 0.08)
        assert np.allclose(lf + lc + lr, 1.0)
        assert (lf > -1e-9).all() and (lc > -1e-9).all() and (lr > -1e-9).all()
        assert lr[-1] > lr[50]          # strong hands raise more


def test_weighted_percentile():
    v = np.array([3.0, 1.0, 2.0, 4.0])
    x = weighted_percentile(v, np.ones(4))
    assert np.allclose(x, [0.625, 0.125, 0.375, 0.875])
    x = weighted_percentile(v, np.array([0.0, 0.0, 1.0, 1.0]))
    assert x[3] > x[2] and np.isclose(x[3], 0.75)


def test_aggression_narrows_range_to_strong_hands():
    g = _play([Action.RAISE_POT, Action.RAISE_POT, Action.RAISE_POT])  # we are seat 1 (big blind)
    obs = g.observation(1)
    hr = HandRange(obs.hole_cards, np.random.default_rng(0), 600)
    idx = hr.valid_indices(obs.board, 300)
    model = OpponentModel()
    opp_events = [e for e in parse(obs.action_history, obs.is_button) if not e.is_me]
    w = hr.weights(opp_events, obs.board, idx, model, DEFAULTS)
    pre = hr.strength[0][idx]
    assert (w * pre).sum() / w.sum() > pre.mean() + 0.1


def test_particles_never_use_known_cards():
    obs = _play([Action.CHECK_CALL, Action.CHECK_CALL]).observation(1)    # flop
    hr = HandRange(obs.hole_cards, np.random.default_rng(3), 600)
    known = set(obs.hole_cards)
    assert not any(known & set(h) for h in hr.pool.tolist())
    idx = hr.valid_indices(obs.board, 1000)
    assert not any(set(obs.board) & set(h) for h in hr.pool[idx].tolist())


# ----------------------------------------------------------------- EV maths
class _Obs:
    """Hand-built observation for EV tests."""
    def __init__(self, **kw):
        base = dict(hand_index=0, street=Street.RIVER, hole_cards=(), board=(), pot=20, to_call=10,
                    my_bet=0, opp_bet=10, my_stack=60, opp_stack=50, is_button=True,
                    legal_actions=(Action.FOLD, Action.CHECK_CALL, Action.RAISE_HALF, Action.RAISE_POT),
                    raise_to={Action.RAISE_HALF: 25, Action.RAISE_POT: 40}, min_raise_to=20,
                    raises_this_street=1, action_history=(), big_blind=2)
        base.update(kw)
        self.__dict__.update(base)


def test_call_ev_is_pot_odds():
    obs = _Obs()
    n = 400
    for eq in (0.0, 0.25, 0.6, 1.0):
        res = np.r_[np.ones(int(eq * n)), np.zeros(n - int(eq * n))]
        evs, E = action_evs(obs, res, np.ones(n), np.linspace(0, 1, n), OpponentModel(), DEFAULTS)
        assert np.isclose(evs[Action.CHECK_CALL], eq * (20 + 10) - 10)
        assert evs[Action.FOLD] == 0.0
    # Break-even price: call 10 into 20 needs 1/3 equity.
    res = np.r_[np.ones(n // 3), np.zeros(n - n // 3)]
    evs, _ = action_evs(obs, res, np.ones(n), np.linspace(0, 1, n), OpponentModel(), DEFAULTS)
    assert abs(evs[Action.CHECK_CALL]) < 0.1


def test_bluff_only_when_fold_equity_pays():
    obs = _Obs(to_call=0, opp_bet=0, legal_actions=(Action.CHECK_CALL, Action.RAISE_HALF, Action.RAISE_POT),
               raise_to={Action.RAISE_HALF: 10, Action.RAISE_POT: 20})
    n = 400
    res = np.zeros(n)                                   # we never win at showdown
    x = np.linspace(0, 1, n)
    folder = OpponentModel()
    for _ in range(300):
        folder.observe(POST_VS_BET, FOLD_O)             # folds 90%+ to bets
    station = OpponentModel()
    for _ in range(300):
        station.observe(POST_VS_BET, CALL_O)
    ev_f, _ = action_evs(obs, res, np.ones(n), x, folder, DEFAULTS)
    ev_s, _ = action_evs(obs, res, np.ones(n), x, station, DEFAULTS)
    assert max(ev_f[Action.RAISE_POT], ev_f[Action.RAISE_HALF]) > ev_f[Action.CHECK_CALL]    # bluff a folder
    assert max(ev_s[Action.RAISE_POT], ev_s[Action.RAISE_HALF]) < ev_s[Action.CHECK_CALL]    # never a station


def test_value_bet_the_nuts_vs_station():
    obs = _Obs(to_call=0, opp_bet=0, legal_actions=(Action.CHECK_CALL, Action.RAISE_HALF, Action.RAISE_POT),
               raise_to={Action.RAISE_HALF: 10, Action.RAISE_POT: 20})
    station = OpponentModel()
    for _ in range(300):
        station.observe(POST_VS_BET, CALL_O)
    n = 400
    evs, _ = action_evs(obs, np.ones(n), np.ones(n), np.linspace(0, 1, n), station, DEFAULTS)
    assert evs[Action.RAISE_POT] > evs[Action.RAISE_HALF] > evs[Action.CHECK_CALL]


# ------------------------------------------------------- opponent learning
def test_model_learns_from_inferred_fold():
    state = BotState(DEFAULTS, seed=1)
    g = Game(make_deal("learn", 0), button_seat=0)
    obs = g.observation(0)                               # we are the button, first to act
    state.last_obs, state.last_action = obs, Action.RAISE_POT
    before = state.model.raw[PRE_VS_RAISE].copy()
    state.on_hand_end(HandResult(0, 2, 8, False, (), None, "me"))
    assert state.model.raw[PRE_VS_RAISE][FOLD_O] == before[FOLD_O] + 1
    # Big blind never acted because the button folded.
    state.on_hand_end(HandResult(1, 1, 3, False, (), None, "me"))
    assert state.model.raw[PRE_OPEN][FOLD_O] == 1


def test_model_frequencies_without_folding_when_unopened():
    m = OpponentModel()
    assert m.freqs(PRE_UNOPENED)[0] == 0.0 and m.freqs(POST_UNOPENED)[0] == 0.0


# ------------------------------------------------------------ legality fuzz
@pytest.mark.parametrize("raise_rate", [0.0, 0.4, 1.0])
def test_every_decision_legal_and_fast(raise_rate):
    rng = random.Random(raise_rate)
    state = BotState(DEFAULTS, seed=2, num_hands=300)
    worst = 0.0
    for hand in range(300):
        g = Game(make_deal(f"fuzz{raise_rate}", hand), button_seat=hand % 2, hand_index=hand)
        while not g.is_terminal:
            obs = g.observation(g.to_act)
            if g.to_act == 0:
                t0 = time.perf_counter()
                a = state.choose_action(obs)
                worst = max(worst, time.perf_counter() - t0)
                assert a in obs.legal_actions
            else:
                raises = [x for x in obs.legal_actions if x in (Action.RAISE_HALF, Action.RAISE_POT)]
                a = rng.choice(raises) if raises and rng.random() < raise_rate else rng.choice(obs.legal_actions)
            g.apply(a)
        state.on_hand_end(g.hand_result(0))
    assert state.errors == [], state.errors[0]
    assert worst < 0.2


def test_cheap_fallback_always_legal():
    rng = random.Random(5)
    for hand in range(300):
        g = Game(make_deal("cheap", hand), button_seat=hand % 2, hand_index=hand)
        while not g.is_terminal:
            obs = g.observation(g.to_act)
            a = cheap_action(obs)
            assert a in obs.legal_actions
            g.apply(a if rng.random() < 0.5 else rng.choice(obs.legal_actions))


def test_garbage_observation_does_not_crash():
    """A strategy failure must still produce a legal action."""
    state = BotState(DEFAULTS, seed=3)
    obs = _Obs(street=Street.FLOP, hole_cards=(0, 1, 2, 3, 4), board=(0, 1, 2))  # impossible cards
    assert state.choose_action(obs) in obs.legal_actions


def test_time_governor_switches_to_cheap_mode():
    p = dict(DEFAULTS)
    state = BotState(p, seed=4, num_hands=1000)
    state.time_used = p["hard_seconds"] + 1
    g = Game(make_deal("gov", 0), button_seat=0)
    obs = g.observation(0)
    assert state.choose_action(obs) in obs.legal_actions
    assert state.fallbacks == 1


# ------------------------------------------------- check-node lookahead (I1)
def _oop_check_obs():
    return _Obs(to_call=0, opp_bet=0, is_button=False, street=Street.FLOP,
                legal_actions=(Action.CHECK_CALL, Action.RAISE_HALF, Action.RAISE_POT),
                raise_to={Action.RAISE_HALF: 10, Action.RAISE_POT: 20})


def _model(unopened_bets: int, unopened_checks: int, folds_to_bet: int = 0, calls_to_bet: int = 0):
    m = OpponentModel()
    for _ in range(unopened_bets):
        m.observe(POST_UNOPENED, RAISE_O)
    for _ in range(unopened_checks):
        m.observe(POST_UNOPENED, CALL_O)
    for _ in range(folds_to_bet):
        m.observe(POST_VS_BET, FOLD_O)
    for _ in range(calls_to_bet):
        m.observe(POST_VS_BET, CALL_O)
    return m


def test_lookahead_equals_plain_check_vs_never_betting_opponent():
    from sdplo.policy import check_ev_oop
    p = dict(DEFAULTS, lookahead=1)
    n = 400
    res = np.r_[np.ones(250), np.zeros(150)]
    x = np.linspace(0, 1, n)
    m = _model(0, 2000)
    R = p["r_post_oop"]
    plain = min(1.0, res.mean() * R) * 20
    assert abs(check_ev_oop(_oop_check_obs(), res, np.ones(n), x, m, p, R) - plain) < 0.3


def test_lookahead_traps_with_nuts_vs_aggressive_bettor():
    """With the nuts vs an opponent who bets almost every time we check and
    calls bets, checking (to call/raise) is worth more than checking with no
    lookahead - and the trap is never worse than giving up the pot."""
    from sdplo.policy import check_ev_oop
    p = dict(DEFAULTS, lookahead=1)
    n = 400
    m = _model(2000, 50, calls_to_bet=500)
    ev = check_ev_oop(_oop_check_obs(), np.ones(n), np.ones(n), np.linspace(0, 1, n), m, p, p["r_post_oop"])
    assert ev > 1.0 * 20 + 5          # more than just the pot


def test_lookahead_never_negative_and_bounded():
    from sdplo.policy import check_ev_oop
    p = dict(DEFAULTS, lookahead=1)
    rng = np.random.default_rng(0)
    for _ in range(50):
        n = 200
        res = (rng.random(n) < rng.random()).astype(float)
        m = _model(int(rng.integers(0, 300)), int(rng.integers(0, 300)), int(rng.integers(0, 100)), int(rng.integers(0, 100)))
        ev = check_ev_oop(_oop_check_obs(), res, rng.random(n) + 0.1, rng.random(n), m, p, p["r_post_oop"])
        assert 0.0 <= ev <= 20 + 2 * 60 + 1e-9


# ------------------------------------------- showdown calibration (I4)
def test_calibration_learns_inverted_betting():
    """Shown down: bets were always weak, checks always strong.  The
    calibrated likelihoods must flip the default 'bets are strong' shape."""
    x = np.array([0.1, 0.9])
    freqs = (0.0, 0.5, 0.5)
    plain = OpponentModel()
    lf, lc, lr = plain.likelihoods(x, freqs, POST_UNOPENED, 0.08)
    assert lr[1] > lr[0]                      # default: strong hands bet
    m = OpponentModel(calib=True, sd_prior=20.0)
    for _ in range(80):
        m.observe_shown(POST_UNOPENED, RAISE_O, 0.05)
        m.observe_shown(POST_UNOPENED, CALL_O, 0.95)
    lf, lc, lr = m.likelihoods(x, freqs, POST_UNOPENED, 0.08)
    assert lr[0] > lr[1] and lc[1] > lc[0]    # learned: weak hands bet, strong hands check
    assert np.allclose(lf + lc + lr, 1.0)


def test_calibration_is_neutral_without_evidence():
    x = np.linspace(0, 1, 21)
    freqs = (0.3, 0.5, 0.2)
    a = OpponentModel().likelihoods(x, freqs, POST_VS_BET, 0.08)
    b = OpponentModel(calib=True).likelihoods(x, freqs, POST_VS_BET, 0.08)
    assert all(np.allclose(u, v) for u, v in zip(a, b))


def test_showdown_replay_records_events():
    p = dict(DEFAULTS, calib=1)
    state = BotState(p, seed=9, num_hands=50)
    rng = random.Random(9)
    for hand in range(50):
        g = Game(make_deal("calib", hand), button_seat=hand % 2, hand_index=hand)
        while not g.is_terminal:
            obs = g.observation(g.to_act)
            a = state.choose_action(obs) if g.to_act == 0 else (
                Action.RAISE_HALF if Action.RAISE_HALF in obs.legal_actions and rng.random() < 0.3 else Action.CHECK_CALL)
            g.apply(a)
        state.on_hand_end(g.hand_result(0))
    assert state.errors == [], state.errors[0]
    assert sum(v.sum() for v in state.model.sd.values()) > 20


# ----------------------------------------- final feature set (I2 + I3 + I4 + I5)
FINAL_FEATURES = dict(ctx_detail=1, calib=1, adaptive_mult=3, overhead_ms=0.8, grace_ms=1.0)


@pytest.mark.parametrize("raise_rate", [0.2, 1.0])
def test_final_features_legal_and_error_free(raise_rate):
    rng = random.Random(7 + raise_rate)
    state = BotState(dict(DEFAULTS, **FINAL_FEATURES), seed=5, num_hands=250)
    worst = 0.0
    for hand in range(250):
        g = Game(make_deal(f"final{raise_rate}", hand), button_seat=hand % 2, hand_index=hand)
        while not g.is_terminal:
            obs = g.observation(g.to_act)
            if g.to_act == 0:
                t0 = time.perf_counter()
                a = state.choose_action(obs)
                worst = max(worst, time.perf_counter() - t0)
                assert a in obs.legal_actions
            else:
                raises = [x for x in obs.legal_actions if x in (Action.RAISE_HALF, Action.RAISE_POT)]
                a = rng.choice(raises) if raises and rng.random() < raise_rate else rng.choice(obs.legal_actions)
            g.apply(a)
        state.on_hand_end(g.hand_result(0))
    assert state.errors == [], state.errors[0]
    assert worst < 0.25
    assert state.fallbacks == 0


def test_detailed_stats_shrink_toward_pooled():
    m = OpponentModel(detail=True, shrink=12.0)
    for _ in range(200):
        m.observe(POST_VS_BET, FOLD_O, street=1, level=1)    # folds a lot on the flop
        m.observe(POST_VS_BET, CALL_O, street=3, level=1)    # never on the river
    flop, river, pooled = (m.freqs(POST_VS_BET, 1, 1)[0], m.freqs(POST_VS_BET, 3, 1)[0], m.freqs(POST_VS_BET)[0])
    assert flop > pooled > river
    assert abs(m.freqs(POST_VS_BET, 2, 1)[0] - pooled) < 1e-12   # unseen bucket = pooled


def test_time_accounting_applies_grace():
    st = BotState(dict(DEFAULTS, overhead_ms=0.8, grace_ms=1.0), seed=1)
    g = Game(make_deal("grace", 0), button_seat=0)
    obs = g.observation(0)
    t0 = time.perf_counter()
    st.choose_action(obs)
    elapsed = time.perf_counter() - t0
    assert st.time_used <= max(0.0, elapsed - 0.0002) + 1e-9
