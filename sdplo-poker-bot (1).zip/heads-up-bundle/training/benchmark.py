"""
benchmark.py - A/B benchmark of bot versions on identical deals.

    python training/benchmark.py --bots b0 cur --deals 1000 --seeds 2 --tag run1
    python training/benchmark.py --bots b0 cur --opps exploiter balanced --seeds 4
    python training/benchmark.py --bots cur --h2h b0 --seeds 8          # head-to-head only

Bot specs:
    b0              the frozen baseline (training/frozen/sdplo_b0 + checkpoints/B0_shipped.json)
    cur             current sdplo code + sdplo/params.json
    cur:FILE.json   current code with another parameter file
    b0:FILE.json    frozen code with another parameter file
Opponent specs: any pool name (see REGISTRY), "adv:FILE.json" (a tuned
ParamAdversary), or a bot spec (for head-to-head).

For every (opponent, seed) all bots play the SAME deals, so the per-deal
difference between two bots removes most card luck: we report it with its
own 95% interval ("paired delta").  Seeds are "bench-<i>", disjoint from
tuning ("train-") and the earlier evaluation ("eval-").

Behaviour stats per bot (our side only):
    VPIP  voluntarily put chips in preflop      PFR  raised preflop
    AF    (bets+raises)/calls postflop          F2B  fold rate when facing a bet/raise
    WTSD  went to showdown | saw flop          AI%  hands that ended with stacks all-in
    BTN/BB  bb per hand in each position       ms   mean / p99 / max decision latency
"""

from __future__ import annotations

import argparse
import json
import math
import os
import sys
import time
from multiprocessing import Pool

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.join(HERE, ".."))
sys.path.insert(0, os.path.join(HERE, "frozen"))

from game import Action, BIG_BLIND, STARTING_STACK, Street  # noqa: E402
import opponents as O  # noqa: E402
from sdplo.params import load_params  # noqa: E402
from sim import play_half  # noqa: E402

ROOT = os.path.join(HERE, "..")
REGISTRY = {o.name: type(o) for o in O.train_pool() + O.heldout_pool() + O.style_pool()}
DEFAULT_OPPS = ["random", "calling_station", "always_pot", "nit", "maniac", "equity_bot",
                "tag", "sticky", "tight_passive", "lag", "balanced", "exploiter"]


def make_bot(spec: str, seed: int = 3):
    kind, _, arg = spec.partition(":")
    if kind == "b0":
        from sdplo_b0.bot import BotState as B0State
        path = arg or os.path.join(ROOT, "checkpoints", "B0_shipped.json")
        return O.SDPLOBot(load_params(path), seed=seed, name="sdplo", state_cls=B0State)  # same RNG stream as cur
    if kind == "cur":
        return O.SDPLOBot(load_params(arg) if arg else load_params(), seed=seed, name="sdplo")
    if kind == "adv":
        with open(arg) as f:
            theta = json.load(f)["theta"]
        return O.ParamAdversary(seed=11, theta=theta, name=os.path.basename(arg))
    return REGISTRY[spec](11)


class Recorder:
    """Wraps a bot and records behaviour stats for the half."""

    def __init__(self, bot):
        self.bot = bot
        self.reset()

    def reset(self):
        self.lat = []
        self.c = dict(hands=0, vpip=0, pfr=0, bets=0, calls=0, faced=0, folds=0, flop=0, sd=0, allin=0)
        self.pos = {True: [], False: []}
        self._hand = None

    def new_half(self, config, memory):
        self.bot.new_half(config, memory)

    def choose_action(self, obs, memory):
        t0 = time.perf_counter()
        a = self.bot.choose_action(obs, memory)
        self.lat.append(time.perf_counter() - t0)
        if self._hand is None or self._hand["i"] != obs.hand_index:
            self._hand = dict(i=obs.hand_index, btn=obs.is_button, vpip=False, pfr=False, flop=False)
        h = self._hand
        if obs.street == Street.PREFLOP:
            if a in (Action.RAISE_HALF, Action.RAISE_POT):
                h["vpip"] = h["pfr"] = True
            elif a == Action.CHECK_CALL and obs.to_call > 0:
                h["vpip"] = True
        else:
            h["flop"] = True
            if a in (Action.RAISE_HALF, Action.RAISE_POT):
                self.c["bets"] += 1
            elif a == Action.CHECK_CALL and obs.to_call > 0:
                self.c["calls"] += 1
        if obs.to_call > 0 and len(obs.action_history) > 0:
            self.c["faced"] += 1
            self.c["folds"] += a == Action.FOLD
        return a

    def on_hand_end(self, result, memory):
        self.bot.on_hand_end(result, memory)
        h = self._hand if (self._hand and self._hand["i"] == result.hand_index) else None
        c = self.c
        c["hands"] += 1
        if h:
            c["vpip"] += h["vpip"]
            c["pfr"] += h["pfr"]
            flop = h["flop"] or (result.went_to_showdown and len(result.board) == 5)
            c["flop"] += flop
            c["sd"] += result.went_to_showdown and flop
            self.pos[h["btn"]].append(result.my_net / BIG_BLIND)
        c["allin"] += result.pot >= 2 * STARTING_STACK

    def summary(self):
        c = self.c
        lat = np.array(self.lat) * 1000 if self.lat else np.zeros(1)
        return dict(VPIP=c["vpip"] / max(1, c["hands"]), PFR=c["pfr"] / max(1, c["hands"]),
                    AF=c["bets"] / max(1, c["calls"]), F2B=c["folds"] / max(1, c["faced"]),
                    WTSD=c["sd"] / max(1, c["flop"]), AI=c["allin"] / max(1, c["hands"]),
                    BTN=float(np.mean(self.pos[True])) if self.pos[True] else 0.0,
                    BB=float(np.mean(self.pos[False])) if self.pos[False] else 0.0,
                    ms_mean=float(lat.mean()), ms_p99=float(np.percentile(lat, 99)), ms_max=float(lat.max()))


def _job(args):
    bot_spec, opp_spec, seed, deals = args
    me = Recorder(make_bot(bot_spec))
    opp = make_bot(opp_spec)
    stats, halves, summ, think = {}, [], [], []
    for half, seats in ((1, {"A": 0, "B": 1}), (2, {"A": 1, "B": 0})):
        me.reset()
        halves.append(play_half({"A": me, "B": opp}, seats, seed, deals, stats, half))
        summ.append(me.summary())
        think.append(stats[("A", half)].time)
    per_deal = [(a + b) / BIG_BLIND for a, b in zip(*halves)]
    beh = {k: (summ[0][k] + summ[1][k]) / 2 for k in summ[0]}
    beh["ms_max"] = max(summ[0]["ms_max"], summ[1]["ms_max"])
    beh["think_s"] = max(think)
    errs = sum(s.errors for (b, _), s in stats.items() if b == "A")
    return bot_spec, opp_spec, seed, per_deal, beh, errs


def ci(xs):
    n = len(xs)
    m = sum(xs) / n
    se = math.sqrt(sum((x - m) ** 2 for x in xs) / (n - 1) / n) if n > 1 else 0.0
    return m, se


def verdict(m, se):
    return "WIN" if m - 1.96 * se > 0 else "LOSS" if m + 1.96 * se < 0 else "CHOP"


def run(bots, opps, seeds, deals, procs=2):
    jobs = [(b, o, s, deals) for o in opps for s in seeds for b in bots if b != o]
    with Pool(procs) as p:
        return p.map(_job, jobs, chunksize=1)


def report(rows, bots, opps, seeds, out_lines):
    by = {(b, o, s): (pd, beh, e) for b, o, s, pd, beh, e in rows}
    say = out_lines.append
    label = {b: (os.path.basename(b.partition(":")[2]).replace(".json", "") or b) for b in bots}
    head = f"{'opponent':16s} {label[bots[0]] + ' bb/deal [95% CI]':>32s}"
    for b in bots[1:]:
        head += f" {label[b] + ' - ' + label[bots[0]]:>22s}"
    say(head)
    points = {b: 0.0 for b in bots}
    means = {b: [] for b in bots}
    deltas = {b: [] for b in bots[1:]}
    for o in opps:
        line = f"{o:16s} "
        for j, b in enumerate(bots):
            if b == o or (j > 0 and bots[0] == o):
                line += f"{'-':>32s} " if j == 0 else f" {'-':>22s}"
                continue
            for s in seeds:
                m_s, se_s = ci(by[(b, o, s)][0])
                v = verdict(m_s, se_s)
                points[b] += 1.0 if v == "WIN" else 0.5 if v == "CHOP" else 0.0
            xs = [x for s in seeds for x in by[(b, o, s)][0]]
            m, se = ci(xs)
            means[b].append(m)
            errs = sum(by[(b, o, s)][2] for s in seeds)
            if j == 0:
                line += f"{m:+8.3f} [{m - 1.96 * se:+7.3f},{m + 1.96 * se:+7.3f}]{' ERR' + str(errs) if errs else '':>5s}"
            else:
                d = [x - y for s in seeds for x, y in zip(by[(b, o, s)][0], by[(bots[0], o, s)][0])]
                md, sed = ci(d)
                deltas[b].append(md)
                line += f" {md:+7.3f} ± {1.96 * sed:5.3f}{'*' if abs(md) > 1.96 * sed else ' '}{'E' if errs else ' '}"
        say(line)
    say("match points: " + ", ".join(f"{label[b]} {points[b]:.1f}" for b in bots))
    say("mean bb/deal over opponents: " + ", ".join(f"{label[b]} {np.mean(means[b]):+.3f}" for b in bots))
    if deltas:
        say("mean paired delta vs " + label[bots[0]] + ": "
            + ", ".join(f"{label[b]} {np.mean(d):+.3f}" for b, d in deltas.items()) + "   (* = significant at 95%)")
    say("")
    say("behaviour (mean over halves/seeds):")
    say(f"{'bot':14s} {'opponent':16s} {'VPIP':>5s} {'PFR':>5s} {'AF':>6s} {'F2B':>5s} {'WTSD':>5s} {'AI%':>5s} "
        f"{'BTN':>7s} {'BB':>7s} {'ms':>5s} {'p99':>5s} {'max':>6s} {'think':>6s}")
    for b in bots:
        for o in opps:
            if b == o:
                continue
            bs = [by[(b, o, s)][1] for s in seeds]
            a = {k: float(np.mean([x[k] for x in bs])) for k in bs[0]}
            a["ms_max"] = max(x["ms_max"] for x in bs)
            a["think_s"] = max(x["think_s"] for x in bs)
            say(f"{label[b][:14]:14s} {o:16s} {a['VPIP']:5.2f} {a['PFR']:5.2f} {min(a['AF'], 999):6.2f} {a['F2B']:5.2f} "
                f"{a['WTSD']:5.2f} {a['AI']:5.2f} {a['BTN']:+7.2f} {a['BB']:+7.2f} {a['ms_mean']:5.2f} "
                f"{a['ms_p99']:5.1f} {a['ms_max']:6.1f} {a['think_s']:6.2f}")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--bots", nargs="+", default=["b0", "cur"])
    ap.add_argument("--opps", nargs="*", default=None)
    ap.add_argument("--h2h", nargs="*", default=[], help="bot specs to play head-to-head as opponents")
    ap.add_argument("--deals", type=int, default=1000)
    ap.add_argument("--seeds", type=int, default=2)
    ap.add_argument("--seed-prefix", default="bench")
    ap.add_argument("--tag", default=None)
    ap.add_argument("--procs", type=int, default=2)
    a = ap.parse_args()
    opps = (DEFAULT_OPPS if a.opps is None else a.opps) + a.h2h
    seeds = [f"{a.seed_prefix}-{i}" for i in range(a.seeds)]
    t0 = time.time()
    rows = run(a.bots, opps, seeds, a.deals, a.procs)
    lines = [f"# benchmark bots={a.bots} deals={a.deals} seeds={seeds} ({time.time() - t0:.0f}s)"]
    report(rows, a.bots, opps, seeds, lines)
    text = "\n".join(lines)
    print(text)
    if a.tag:
        os.makedirs(os.path.join(HERE, "results"), exist_ok=True)
        with open(os.path.join(HERE, "results", f"bench_{a.tag}.txt"), "w") as f:
            f.write(text + "\n")
        with open(os.path.join(HERE, "results", f"bench_{a.tag}.json"), "w") as f:
            json.dump([[b, o, s, pd, beh, e] for b, o, s, pd, beh, e in rows], f)


if __name__ == "__main__":
    main()
