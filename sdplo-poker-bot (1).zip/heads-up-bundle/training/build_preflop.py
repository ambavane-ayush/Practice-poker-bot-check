"""
build_preflop.py - precompute preflop hand strength for all 376,992 hands.

Outputs sdplo/data/preflop.npz with two uint16 arrays indexed by
fasteval.hand_index (value / 65535 = equity):

    eq_rand    all-in equity vs a uniformly random 5-card hand
    eq_strong  all-in equity vs a hand drawn from the top 25% (by eq_rand)

The two together capture raw strength and "playability" (how a hand holds up
against the hands that actually put money in).  Suit isomorphism (24 suit
permutations) cuts the work to ~16k canonical classes.

Usage:  python training/build_preflop.py [--samples 3000] [--seed 1] [--procs 2]
Runtime on 2 cores: a few minutes.  Deterministic for a given seed.
"""

from __future__ import annotations

import argparse
import os
import sys
import time
from itertools import permutations
from multiprocessing import Pool

import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from sdplo import fasteval as fe  # noqa: E402

OUT = os.path.join(os.path.dirname(__file__), "..", "sdplo", "data", "preflop.npz")


def canonical_indices(hands: np.ndarray) -> np.ndarray:
    """Smallest hand_index over the 24 suit relabelings of each hand."""
    rank = hands.astype(np.int64) >> 2
    suit = hands.astype(np.int64) & 3
    best = None
    for perm in permutations(range(4)):
        p = np.array(perm, dtype=np.int64)
        idx = fe.hand_index(rank * 4 + p[suit])
        best = idx if best is None else np.minimum(best, idx)
    return best


def _equity_chunk(args) -> np.ndarray:
    """Equity of each hero hand in `heroes` (C, 5) vs opponents.
    If `opp_pool` is None the opponent is uniform; otherwise opponents are
    drawn uniformly from opp_pool (K, 5) with card-removal by rejection."""
    heroes, opp_pool, samples, seed = args
    rng = np.random.default_rng(seed)
    out = np.empty(len(heroes))
    all_cards = np.arange(36)
    for i, hero in enumerate(heroes):
        rest = np.setdiff1d(all_cards, hero)                  # 31 cards
        if opp_pool is None:
            keys = rng.random((samples, 31))
            pick = rest[np.argpartition(keys, 10, axis=1)[:, :10]]
            opp, board = pick[:, :5], pick[:, 5:]
        else:
            hero_mask = int(sum(1 << int(c) for c in hero))
            cand = opp_pool[rng.integers(0, len(opp_pool), samples * 3)]
            cmask = (np.int64(1) << cand.astype(np.int64)).sum(1)
            ok = (cmask & hero_mask) == 0
            opp = cand[ok][:samples]
            n = len(opp)
            used = np.zeros((n, 36), dtype=bool)
            used[:, hero] = True
            used[np.arange(n)[:, None], opp] = True
            keys = rng.random((n, 36)) + used * 2.0           # used cards sort last
            board = np.argpartition(keys, 5, axis=1)[:, :5]
        hs = fe.omaha_scores(np.broadcast_to(hero, opp.shape), board)
        os_ = fe.omaha_scores(opp, board)
        out[i] = (np.sum(hs > os_) + 0.5 * np.sum(hs == os_)) / len(opp)
    return out


def run(samples: int, seed: int, procs: int) -> None:
    t0 = time.time()
    hands = fe.all_hands()
    canon = canonical_indices(hands)
    classes, inverse = np.unique(canon, return_inverse=True)
    reps = hands[classes].astype(np.int64)
    print(f"{len(hands)} hands, {len(classes)} suit classes ({time.time() - t0:.1f}s)")

    def parallel(pool_hands, n_samples, salt):
        chunks = np.array_split(np.arange(len(reps)), 64)
        jobs = [(reps[c], pool_hands, n_samples, seed * 1000 + salt * 100 + j) for j, c in enumerate(chunks)]
        with Pool(procs) as p:
            return np.concatenate(p.map(_equity_chunk, jobs))

    eq_rand_cls = parallel(None, samples, 1)
    print(f"eq_rand done ({time.time() - t0:.1f}s)")
    eq_rand = eq_rand_cls[inverse]
    top = hands[eq_rand >= np.quantile(eq_rand, 0.75)].astype(np.int64)
    eq_strong_cls = parallel(top, samples, 2)
    print(f"eq_strong done ({time.time() - t0:.1f}s)")
    eq_strong = eq_strong_cls[inverse]

    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    np.savez_compressed(OUT,
                        eq_rand=np.round(eq_rand * 65535).astype(np.uint16),
                        eq_strong=np.round(eq_strong * 65535).astype(np.uint16))
    print(f"saved {OUT}; eq_rand range {eq_rand.min():.3f}-{eq_rand.max():.3f}, "
          f"eq_strong range {eq_strong.min():.3f}-{eq_strong.max():.3f}")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--samples", type=int, default=3000)
    ap.add_argument("--seed", type=int, default=1)
    ap.add_argument("--procs", type=int, default=2)
    a = ap.parse_args()
    run(a.samples, a.seed, a.procs)
