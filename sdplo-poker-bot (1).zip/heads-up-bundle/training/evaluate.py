"""
evaluate.py - score a parameter set against the opponent pools.

    python training/evaluate.py                        # sdplo/params.json vs everything
    python training/evaluate.py --params ckpt.json --deals 1000 --seeds 2
    python training/evaluate.py --vs checkpoints/gen_03.json   # head-to-head vs an older version

Each line is one full duplicate match (both halves, same cards, seats swapped)
scored exactly like the tournament: mean bb/deal for us, 95% interval, verdict.
Evaluation seeds start with "eval-" and never overlap the "train-" seeds used
by tune.py.
"""

from __future__ import annotations

import argparse
import json
import os
import sys
from multiprocessing import Pool

sys.path.insert(0, os.path.dirname(__file__))
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from opponents import SDPLOBot, heldout_pool, train_pool  # noqa: E402
from sdplo.params import load_params  # noqa: E402
from sim import play_match  # noqa: E402


def _job(args):
    params, opp_spec, seed, deals = args
    kind, payload = opp_spec
    if kind == "pool":
        opp = {o.name: o for o in train_pool(7) + heldout_pool(7)}[payload]
    else:
        opp = SDPLOBot(load_params(payload), seed=7, name="old")
    me = SDPLOBot(params, seed=3)
    r = play_match(me, opp, seed=seed, deals=deals)
    t = max(r.stats[("A", 1)].time, r.stats[("A", 2)].time)
    err = r.stats[("A", 1)].errors + r.stats[("A", 2)].errors
    return opp.name if kind == "pool" else os.path.basename(payload), seed, r.mean, r.se, r.verdict, t, err


def evaluate(params, opponents, seeds, deals, procs=2):
    jobs = [(params, o, s, deals) for o in opponents for s in seeds]
    with Pool(procs) as p:
        return p.map(_job, jobs)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--params", default=None)
    ap.add_argument("--deals", type=int, default=1000)
    ap.add_argument("--seeds", type=int, default=1)
    ap.add_argument("--vs", nargs="*", default=[], help="older parameter files to play head-to-head")
    ap.add_argument("--only", nargs="*", default=None, help="restrict to these pool opponents")
    ap.add_argument("--json", default=None)
    a = ap.parse_args()
    params = load_params(a.params) if a.params else load_params()
    names = [o.name for o in train_pool() + heldout_pool()]
    if a.only is not None:
        names = [n for n in names if n in a.only]
    opponents = [("pool", n) for n in names] + [("file", f) for f in a.vs]
    seeds = [f"eval-{i}" for i in range(a.seeds)]
    rows = evaluate(params, opponents, seeds, a.deals)
    held = {o.name for o in heldout_pool()}
    print(f"{'opponent':18s} {'seed':8s} {'bb/deal':>8s} {'95% CI':>18s}  verdict   think(s) errors")
    pts = 0.0
    for name, seed, m, se, v, t, err in rows:
        tag = " (held-out)" if name in held else ""
        print(f"{name:18s} {seed:8s} {m:+8.3f} [{m - 1.96 * se:+7.3f},{m + 1.96 * se:+7.3f}]  "
              f"{v:8s} {t:7.2f} {err:4d}{tag}")
        pts += 1.0 if v.startswith("WIN") else 0.5 if v == "CHOP" else 0.0
    print(f"points {pts:.1f} / {len(rows)}   mean bb/deal {sum(r[2] for r in rows) / len(rows):+.3f}")
    if a.json:
        with open(a.json, "w") as f:
            json.dump(rows, f, indent=1)


if __name__ == "__main__":
    main()
