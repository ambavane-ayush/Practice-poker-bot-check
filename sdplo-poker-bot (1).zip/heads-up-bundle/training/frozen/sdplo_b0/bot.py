"""
bot.py - the bot: glue between the judge's interface and the strategy.

    state = BotState(params, seed)       # one per half (kept in `memory`)
    action = state.choose_action(obs)    # always a legal Action
    state.on_hand_end(result)

Safety layers (a forfeit loses the whole match, so robustness comes first):
  1. the full strategy runs inside try/except;
  2. on any exception, or when the time bank is low, a cheap rule-based
     fallback decides;
  3. whatever comes out is checked against obs.legal_actions, and replaced by
     CHECK_CALL (always legal) if needed.
"""

from __future__ import annotations

import time
import traceback
from dataclasses import dataclass

import numpy as np

from game import Action, Street

from . import fasteval as fe
from .history import (POST_UNOPENED, POST_VS_BET, PRE_OPEN, PRE_VS_RAISE, RAISE_O, Event,
                      parse, FOLD_O, CALL_O)
from .opponent import OpponentModel
from .policy import action_evs, cheap_action, choose
from .ranges import HandRange, weighted_percentile


@dataclass(frozen=True)
class _MyAction:
    """Our own action in the same shape as game.ObservedAction."""
    street: Street
    is_me: bool
    action: Action
    amount: int
    street_total: int


def _my_observed_action(obs, action: Action) -> _MyAction:
    if action == Action.FOLD:
        amount = 0
    elif action == Action.CHECK_CALL:
        amount = min(obs.to_call, obs.my_stack)
    else:
        amount = obs.raise_to.get(action, obs.my_bet) - obs.my_bet
    return _MyAction(obs.street, True, action, amount, obs.my_bet + amount)


class BotState:
    def __init__(self, params: dict, seed: int = 0, num_hands: int = 1000) -> None:
        self.p = params
        self.rng = np.random.default_rng(seed)
        self.model = OpponentModel(prior_strength=params["prior_strength"])
        self.num_hands = max(1, num_hands)
        self.cur_hand = -1
        self.hrange: HandRange | None = None
        self.last_obs = None
        self.last_action: Action | None = None
        self.time_used = 0.0
        self.decisions = 0
        self.fallbacks = 0
        self.errors: list[str] = []

    # ------------------------------------------------------------------ act
    def choose_action(self, obs) -> Action:
        t0 = time.perf_counter()
        action = None
        try:
            if obs.hand_index != self.cur_hand:
                self.cur_hand = obs.hand_index
                self.hrange = None
            mode = self._budget_mode(obs.hand_index)
            if mode == "cheap":
                self.fallbacks += 1
                action = cheap_action(obs)
            else:
                action = self._strategy(obs, mode)
        except Exception:  # never let a bug reach the judge
            if len(self.errors) < 20:
                self.errors.append(traceback.format_exc())
            try:
                self.fallbacks += 1
                action = cheap_action(obs)
            except Exception:
                action = None
        if action not in obs.legal_actions:
            action = Action.CHECK_CALL
        self.last_obs, self.last_action = obs, action
        self.decisions += 1
        self.time_used += time.perf_counter() - t0 + self.p["overhead_ms"] / 1000.0
        return action

    def _budget_mode(self, hand_index: int) -> str:
        if self.time_used > self.p["hard_seconds"]:
            return "cheap"
        allowance = self.p["target_seconds"] * (hand_index + 1) / self.num_hands
        if self.time_used > 1.25 * allowance + 0.3:
            return "lean"
        return "full"

    def _strategy(self, obs, mode: str) -> Action:
        p = self.p
        if self.hrange is None:
            self.hrange = HandRange(obs.hole_cards, self.rng, int(p["pool_size"]))
        hr = self.hrange
        n = int(p["n_particles_pre"] if obs.street == Street.PREFLOP else p["n_particles"])
        if mode != "full":
            n = max(60, n // 3)
        runouts = int(p["runouts_flop"]) if (obs.street == Street.FLOP and mode == "full") else 1
        board = tuple(obs.board)
        idx = hr.valid_indices(board, n)
        if len(idx) < 20:
            return cheap_action(obs)
        opp_events = [e for e in parse(obs.action_history, obs.is_button) if not e.is_me]
        w = hr.weights(opp_events, board, idx, self.model, p)
        res, owner = hr.showdown_results(board, idx, runouts)
        wr = w[owner]
        s_cur = hr.street_strength(int(obs.street), board, idx, p["draw_weight"])
        x_cur = weighted_percentile(s_cur, w)[owner]
        evs, _E = action_evs(obs, res, wr, x_cur, self.model, p)
        return choose(evs, p, obs.big_blind, self.rng)

    # ------------------------------------------------------------- learning
    def on_hand_end(self, result) -> None:
        t0 = time.perf_counter()
        try:
            self._learn(result)
        except Exception:
            if len(self.errors) < 20:
                self.errors.append(traceback.format_exc())
        finally:
            self.model.hands += 1
            self.time_used += time.perf_counter() - t0   # the judge times this too
            self.hrange = None
            self.last_obs = None
            self.last_action = None

    def _learn(self, result) -> None:
        obs, act = self.last_obs, self.last_action
        if obs is None or obs.hand_index != result.hand_index:
            # We never acted: we were the big blind and the button folded.
            if not result.went_to_showdown and result.winner == "me":
                self.model.observe(PRE_OPEN, FOLD_O)
            return
        history = list(obs.action_history) + [_my_observed_action(obs, act)]
        events = [e for e in parse(history, obs.is_button) if not e.is_me]
        # Infer the opponent's final, unseen action.
        raised = act in (Action.RAISE_HALF, Action.RAISE_POT)
        resp_ctx = PRE_VS_RAISE if obs.street == Street.PREFLOP else POST_VS_BET
        if raised and not result.went_to_showdown and result.winner == "me":
            events.append(Event(int(obs.street), False, FOLD_O, resp_ctx, 0, 0))
        elif raised and result.went_to_showdown:
            events.append(Event(int(obs.street), False, CALL_O, resp_ctx, 0, 0))
        elif (act == Action.CHECK_CALL and obs.to_call == 0 and result.went_to_showdown
              and obs.street == Street.RIVER and not obs.is_button):
            events.append(Event(int(Street.RIVER), False, CALL_O, POST_UNOPENED, 0, 0))
        for e in events:
            self.model.observe(e.context, e.outcome)
        # Showdown after the opponent was aggressive: was it a weak hand?
        if result.went_to_showdown and result.opp_hole is not None:
            aggr = [e.street for e in events if e.outcome == RAISE_O]
            if aggr:
                pct = showdown_percentile(result.opp_hole, result.board, aggr[-1], self.rng,
                                          self.p["draw_weight"])
                self.model.observe_showdown_aggression(pct)


def showdown_percentile(opp_hole, board, street: int, rng, draw_weight: float, n: int = 300) -> float:
    """Percentile of the opponent's hand among random hands, measured on the
    street of its last aggressive action (board cards known by then only)."""
    nb = {0: 0, 1: 3, 2: 4, 3: 5}[int(street)]
    vis = np.asarray(board[:nb], dtype=np.int64)
    opp = np.asarray(opp_hole, dtype=np.int64)
    if nb == 0:
        from .tables import PRE_PCT
        return float(PRE_PCT[fe.hand_index(opp)])
    hr = HandRange(opp, rng, n)                 # random hands that avoid the opponent's cards
    idx = hr.valid_indices(vis, n)
    hands = np.concatenate([hr.pool[idx], opp[None, :]])
    s = hr._compute_strength(hands, vis, draw_weight)
    return float((s[:-1] < s[-1]).mean() + 0.5 * (s[:-1] == s[-1]).mean())
