"""
history.py - turn obs.action_history into events with betting context.

Each event says who acted, on which street, what they did and what situation
they were in (the "context").  Contexts are the buckets the opponent model
counts frequencies in:

    PRE_OPEN       preflop, button's first action (facing only the blind)
    PRE_UNOPENED   preflop, big blind after a limp (can check)
    PRE_VS_RAISE   preflop, facing a voluntary raise
    POST_UNOPENED  flop/turn/river, nothing to call (check or bet)
    POST_VS_BET    flop/turn/river, facing a bet or raise

Outcomes are coded 0 = fold, 1 = check/call, 2 = raise.
"""

from __future__ import annotations

from dataclasses import dataclass

from game import BIG_BLIND, SMALL_BLIND, Action, Street

PRE_OPEN, PRE_UNOPENED, PRE_VS_RAISE, POST_UNOPENED, POST_VS_BET = range(5)
CONTEXT_NAMES = ("PRE_OPEN", "PRE_UNOPENED", "PRE_VS_RAISE", "POST_UNOPENED", "POST_VS_BET")
FOLD_O, CALL_O, RAISE_O = 0, 1, 2



def outcome_of(action: Action) -> int:
    if action == Action.FOLD:
        return FOLD_O
    if action == Action.CHECK_CALL:
        return CALL_O
    return RAISE_O


@dataclass(frozen=True)
class Event:
    street: int
    is_me: bool
    outcome: int
    context: int
    pot_before: int       # pot before this action
    to_call: int          # what the actor owed before acting


def context_for(street: int, faced: bool, first_preflop_action: bool) -> int:
    if street == Street.PREFLOP:
        if first_preflop_action:
            return PRE_OPEN
        return PRE_VS_RAISE if faced else PRE_UNOPENED
    return POST_VS_BET if faced else POST_UNOPENED


def parse(history, i_am_button: bool) -> list[Event]:
    """Rebuild contexts by replaying bets (blinds are implicit)."""
    events: list[Event] = []
    street = Street.PREFLOP
    my_bet = SMALL_BLIND if i_am_button else BIG_BLIND
    opp_bet = BIG_BLIND if i_am_button else SMALL_BLIND
    pot = SMALL_BLIND + BIG_BLIND
    for idx, a in enumerate(history):
        if a.street != street:
            street = a.street
            my_bet = opp_bet = 0
        actor_bet = my_bet if a.is_me else opp_bet
        other_bet = opp_bet if a.is_me else my_bet
        to_call = max(0, other_bet - actor_bet)
        ctx = context_for(int(street), to_call > 0, idx == 0)
        events.append(Event(int(street), a.is_me, outcome_of(a.action), ctx, pot, to_call))
        pot += a.amount
        if a.is_me:
            my_bet = a.street_total
        else:
            opp_bet = a.street_total
    return events


def current_context(obs) -> int:
    """Context of the decision we are making now."""
    return context_for(int(obs.street), obs.to_call > 0, len(obs.action_history) == 0)


def opp_response_context(obs) -> int:
    """Context the opponent will be in after we bet/raise now."""
    return PRE_VS_RAISE if obs.street == Street.PREFLOP else POST_VS_BET
