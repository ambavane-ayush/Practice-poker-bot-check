"""
opponent.py - online opponent model (lives in `memory`, reset every half).

For each betting context (see history.py) we count how often the opponent
folds, checks/calls and raises, starting from prior pseudo-counts so early
estimates are sensible.  We also estimate the share of the opponent's raises
that are "bluffs" (weak hands) from showdowns.

These frequencies drive two things:
  * ranges.py turns them into likelihoods P(action | hand strength) and
    narrows the opponent's range with Bayes' rule;
  * policy.py uses the fold frequency as fold equity when we bet.
"""

from __future__ import annotations

import numpy as np

from .history import (CALL_O, FOLD_O, POST_UNOPENED, POST_VS_BET, PRE_OPEN, PRE_UNOPENED,
                      PRE_VS_RAISE, RAISE_O)

# Prior (fold, call, raise) frequencies per context.
PRIORS = {
    PRE_OPEN: (0.25, 0.35, 0.40),
    PRE_UNOPENED: (0.00, 0.65, 0.35),
    PRE_VS_RAISE: (0.30, 0.50, 0.20),
    POST_UNOPENED: (0.00, 0.55, 0.45),
    POST_VS_BET: (0.40, 0.45, 0.15),
}


class OpponentModel:
    def __init__(self, prior_strength: float = 15.0, bluff_prior: float = 0.15,
                 bluff_prior_strength: float = 8.0) -> None:
        self.counts = {c: np.array(p, dtype=float) * prior_strength for c, p in PRIORS.items()}
        self.raw = {c: np.zeros(3) for c in PRIORS}           # observed only (for reports)
        self.bluffs = bluff_prior * bluff_prior_strength      # weak hands shown after aggression
        self.shown_aggr = bluff_prior_strength                 # aggressive lines shown down
        self.hands = 0

    # ----- updates -----------------------------------------------------------
    def observe(self, context: int, outcome: int) -> None:
        self.counts[context][outcome] += 1.0
        self.raw[context][outcome] += 1.0

    def observe_showdown_aggression(self, strength_pct: float, weak_cut: float = 0.35) -> None:
        """Opponent showed down a hand after betting/raising on its last
        aggressive street; strength_pct is that hand's percentile (0..1)."""
        self.shown_aggr += 1.0
        if strength_pct < weak_cut:
            self.bluffs += 1.0

    # ----- queries -----------------------------------------------------------
    def freqs(self, context: int) -> tuple[float, float, float]:
        c = self.counts[context]
        f = c / c.sum()
        if context in (PRE_UNOPENED, POST_UNOPENED):
            f = np.array([0.0, f[1] + f[0], f[2]])  # no folding when checking is free
        return float(f[0]), float(f[1]), float(f[2])

    def bluff_share(self) -> float:
        return float(np.clip(self.bluffs / self.shown_aggr, 0.02, 0.6))

    def fold_to_bet(self, preflop: bool) -> float:
        return self.freqs(PRE_VS_RAISE if preflop else POST_VS_BET)[FOLD_O]

    def summary(self) -> dict:
        return {
            "hands": self.hands,
            "bluff_share": round(self.bluff_share(), 3),
            **{name: [round(x, 3) for x in self.freqs(c)]
               for name, c in (("pre_open", PRE_OPEN), ("pre_unopened", PRE_UNOPENED),
                               ("pre_vs_raise", PRE_VS_RAISE), ("post_unopened", POST_UNOPENED),
                               ("post_vs_bet", POST_VS_BET))},
        }


__all__ = ["OpponentModel", "PRIORS", "FOLD_O", "CALL_O", "RAISE_O"]
