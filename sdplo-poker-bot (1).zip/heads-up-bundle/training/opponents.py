"""
opponents.py - opponent pool for training and evaluation.

TRAIN pool (used by tune.py):
    starter, guide_example, random, calling_station, always_half, always_pot,
    nit, maniac, equity_bot, plus frozen copies of our own bot (self-play league).
HELD-OUT pool (only used by evaluate.py, never for tuning):
    tag (tight-aggressive equity bot with its own thresholds),
    sticky (loose-passive bot that calls draws and pairs),
    our previous checkpoints.

All bots keep their state in `memory` like a real agent, and are seeded so
matches are reproducible.
"""

from __future__ import annotations

import os
import sys
import zlib

import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from evaluator import FLUSH, STRAIGHT, THREE_OF_A_KIND, TWO_PAIR, omaha_score  # noqa: E402
from game import Action, Street  # noqa: E402
from sdplo import fasteval as fe  # noqa: E402
from sdplo.bot import BotState  # noqa: E402
from sdplo.tables import preflop_info  # noqa: E402

R_HALF, R_POT, CALL, FOLD = Action.RAISE_HALF, Action.RAISE_POT, Action.CHECK_CALL, Action.FOLD


class Bot:
    name = "bot"

    def __init__(self, seed: int = 0) -> None:
        self.seed = seed
        self.halves = 0

    def new_half(self, config, memory):
        self.halves += 1
        memory["rng"] = np.random.default_rng(zlib.crc32(f"{self.name}:{self.seed}:{self.halves}".encode()))

    def on_hand_end(self, result, memory):
        pass

    @staticmethod
    def fold_or_check(obs):
        return FOLD if FOLD in obs.legal_actions else CALL


class Starter(Bot):
    name = "starter"

    def choose_action(self, obs, memory):
        return CALL if obs.to_call == 0 else FOLD


class GuideExample(Bot):
    """The example strategy printed in the participant guide."""
    name = "guide_example"

    def choose_action(self, obs, memory):
        if obs.street != Street.RIVER:
            if obs.to_call <= obs.big_blind:
                return CALL
            return self.fold_or_check(obs)
        score = omaha_score(obs.hole_cards, obs.board)
        if score >= (FLUSH << 20) and R_POT in obs.legal_actions:
            return R_POT
        return CALL


class RandomBot(Bot):
    name = "random"

    def choose_action(self, obs, memory):
        return obs.legal_actions[int(memory["rng"].integers(len(obs.legal_actions)))]


class CallingStation(Bot):
    name = "calling_station"

    def choose_action(self, obs, memory):
        return CALL


class AlwaysHalf(Bot):
    name = "always_half"

    def choose_action(self, obs, memory):
        return R_HALF if R_HALF in obs.legal_actions else CALL


class AlwaysPot(Bot):
    name = "always_pot"

    def choose_action(self, obs, memory):
        return R_POT if R_POT in obs.legal_actions else CALL


def made_category(obs) -> int:
    return int(fe.made_scores(np.array([obs.hole_cards]), np.array(obs.board))[0]) >> 20


def equity_vs_random(obs, rng, n: int = 150) -> float:
    """Monte-Carlo equity vs one uniformly random hand (what many bots use)."""
    if obs.street == Street.PREFLOP:
        return preflop_info(obs.hole_cards)[0]
    hole = np.array(obs.hole_cards)
    board = np.array(obs.board, dtype=np.int64)
    rest = np.setdiff1d(np.arange(36), np.concatenate([hole, board]))
    k = 5 + (5 - len(board))
    pick = rest[np.argpartition(rng.random((n, len(rest))), k - 1, axis=1)[:, :k]]
    opp, run = pick[:, :5], pick[:, 5:]
    full = np.concatenate([np.broadcast_to(board, (n, len(board))), run], axis=1)
    h = fe.omaha_scores(np.broadcast_to(hole, (n, 5)), full)
    o = fe.omaha_scores(opp, full)
    return float(((h > o) + 0.5 * (h == o)).mean())


class Nit(Bot):
    """Plays only strong hands; bets big with them, gives up otherwise."""
    name = "nit"

    def choose_action(self, obs, memory):
        legal = obs.legal_actions
        if obs.street == Street.PREFLOP:
            pct = preflop_info(obs.hole_cards)[2]
            if pct > 0.9 and R_POT in legal:
                return R_POT
            if pct > 0.7 and obs.to_call <= 6:
                return CALL
            return CALL if obs.to_call == 0 else FOLD
        cat = made_category(obs)
        if cat >= THREE_OF_A_KIND:
            return R_POT if R_POT in legal else CALL
        if cat >= STRAIGHT and obs.to_call <= obs.pot // 2:
            return CALL
        return CALL if obs.to_call == 0 else FOLD


class Maniac(Bot):
    """Raises most of the time, almost never folds."""
    name = "maniac"

    def choose_action(self, obs, memory):
        u = memory["rng"].random()
        legal = obs.legal_actions
        if u < 0.55 and R_POT in legal:
            return R_POT
        if u < 0.75 and R_HALF in legal:
            return R_HALF
        if FOLD in legal and obs.to_call > 30 and u > 0.9:
            return FOLD
        return CALL


class EquityBot(Bot):
    """'Rational' baseline: equity vs a random hand against pot odds.
    Thresholds are parameters so we can make different personalities."""
    name = "equity_bot"

    def __init__(self, seed=0, raise_pot=0.68, raise_half=0.58, call_margin=0.03, bluff=0.08):
        super().__init__(seed)
        self.t = (raise_pot, raise_half, call_margin, bluff)

    def choose_action(self, obs, memory):
        rng = memory["rng"]
        legal = obs.legal_actions
        rp, rh, margin, bluff = self.t
        eq = equity_vs_random(obs, rng)
        if eq > rp and R_POT in legal:
            return R_POT
        if eq > rh and R_HALF in legal and obs.raises_this_street < 2:
            return R_HALF
        if obs.to_call == 0:
            if R_HALF in legal and rng.random() < bluff:
                return R_HALF
            return CALL
        price = obs.to_call / (obs.pot + obs.to_call)
        return CALL if eq > price + margin else FOLD


class TAG(EquityBot):
    """HELD-OUT: tighter, more aggressive equity bot."""
    name = "tag"

    def __init__(self, seed=0):
        super().__init__(seed, raise_pot=0.62, raise_half=0.55, call_margin=0.08, bluff=0.15)


class Sticky(Bot):
    """HELD-OUT: loose-passive; calls with any pair or draw, raises the nuts-ish."""
    name = "sticky"

    def choose_action(self, obs, memory):
        legal = obs.legal_actions
        if obs.street == Street.PREFLOP:
            return CALL if obs.to_call <= 10 or preflop_info(obs.hole_cards)[2] > 0.6 else FOLD
        cat = made_category(obs)
        if cat >= FLUSH and R_HALF in legal:
            return R_HALF
        if cat >= 1 or obs.street != Street.RIVER:
            return CALL
        return self.fold_or_check(obs)


class SDPLOBot(Bot):
    """Our bot (sdplo) with a given parameter set.  `state_cls` lets us run a
    frozen older version of the code (e.g. training/frozen/sdplo_b0)."""
    name = "sdplo"

    def __init__(self, params: dict, seed: int = 0, name: str | None = None, state_cls=None):
        super().__init__(seed)
        self.params = dict(params)
        self.state_cls = state_cls or BotState
        if name:
            self.name = name

    def new_half(self, config, memory):
        self.halves += 1
        memory["state"] = self.state_cls(self.params, seed=zlib.crc32(f"{self.name}:{self.seed}:{self.halves}".encode()),
                                         num_hands=config.num_hands)

    def choose_action(self, obs, memory):
        return memory["state"].choose_action(obs)

    def on_hand_end(self, result, memory):
        memory["state"].on_hand_end(result)


# ---------------------------------------------------------------------------
# Style opponents built on a cheap "strength percentile" x in [0, 1]:
# preflop = precomputed percentile; postflop = made hand + draws, ranked
# against random hands (sdplo.ranges strength model).  They never see our cards.
# ---------------------------------------------------------------------------

def strength_pct(obs, rng, n: int = 150) -> float:
    if obs.street == Street.PREFLOP:
        return preflop_info(obs.hole_cards)[2]
    from sdplo.ranges import HandRange
    hole = np.asarray(obs.hole_cards, dtype=np.int64)
    hr = HandRange(hole, rng, n)
    idx = hr.valid_indices(obs.board, n)
    hands = np.concatenate([hr.pool[idx], hole[None, :]])
    s = hr._compute_strength(hands, np.asarray(obs.board, dtype=np.int64), 0.6)
    return float((s[:-1] < s[-1]).mean() + 0.5 * (s[:-1] == s[-1]).mean())


def _raise(obs, pot_size: bool):
    a = R_POT if pot_size else R_HALF
    if a in obs.legal_actions:
        return a
    return R_HALF if R_HALF in obs.legal_actions else CALL


class TightPassive(Bot):
    """Few hands, rarely raises, calls down with good made hands."""
    name = "tight_passive"

    def choose_action(self, obs, memory):
        x = strength_pct(obs, memory["rng"])
        if obs.street == Street.PREFLOP:
            if x > 0.95:
                return _raise(obs, False)
            if x > 0.55 or obs.to_call == 0:
                return CALL
            return FOLD
        if x > 0.88 and obs.raises_this_street == 0:
            return _raise(obs, False)
        if obs.to_call == 0 or x > 0.55:
            return CALL
        return FOLD


class LooseAggressive(Bot):
    """Plays most hands, bets and raises a lot, bluffs often but does fold."""
    name = "lag"

    def choose_action(self, obs, memory):
        rng = memory["rng"]
        x = strength_pct(obs, rng)
        price = obs.to_call / (obs.pot + obs.to_call) if obs.to_call else 0.0
        if obs.street == Street.PREFLOP:
            if x > 0.5 and obs.raises_this_street < 3:
                return _raise(obs, True)
            return CALL if (x > 0.15 or obs.to_call == 0) and price < 0.4 else self.fold_or_check(obs)
        if obs.to_call == 0:
            return _raise(obs, x > 0.7) if (x > 0.5 or rng.random() < 0.35) else CALL
        if x > 0.82 and obs.raises_this_street < 3:
            return _raise(obs, True)
        return CALL if x > 0.3 + price * 0.5 else FOLD


class Balanced(Bot):
    """Heuristic 'balanced' player: value-bets its top quarter, bluffs its
    bottom ~12% (about 1 bluff per 2 value bets, as for a pot-size bet), and
    defends roughly the minimum-defence frequency P/(P+b) against bets."""
    name = "balanced"

    def choose_action(self, obs, memory):
        rng = memory["rng"]
        x = strength_pct(obs, rng)
        if obs.street == Street.PREFLOP:
            if x > 0.7 and obs.raises_this_street < 2:
                return _raise(obs, True)
            if obs.to_call == 0 or x > 0.25 + 0.6 * obs.to_call / (obs.pot + obs.to_call):
                return CALL
            return FOLD
        if obs.to_call == 0:
            if x > 0.75 or x < 0.12:
                return _raise(obs, True)
            return CALL
        b, P = obs.to_call, obs.pot - obs.to_call      # bet faced, pot before it
        if x > 0.92 and obs.raises_this_street < 3:
            return _raise(obs, True)
        return CALL if x > b / max(1, P + b) else FOLD


class Exploiter(Bot):
    """ADAPTIVE: measures how often WE fold to bets (per street) and how often
    we bet when checked to, then bluffs exactly when our fold rate makes a
    bluff profitable, and widens/tightens its calls against our bets according
    to how aggressive we have been."""
    name = "exploiter"

    def new_half(self, config, memory):
        super().new_half(config, memory)
        memory["faced"] = np.ones(4) * 4        # bets we faced, per street (prior 4)
        memory["folded"] = np.ones(4) * 1.6     # ... of which we folded (prior 40%)
        memory["opps"] = 5.0                    # times checked to us postflop
        memory["stabs"] = 2.0                   # ... times we bet
        memory["pending"] = []

    def _track(self, obs, memory):
        # Our responses to its bets are visible in the history it sees.
        hist = obs.action_history
        for i in range(1, len(hist)):
            prev, cur = hist[i - 1], hist[i]
            if cur.is_me or not prev.is_me:
                continue
            key = (obs.hand_index, i)
            if key in memory.setdefault("seen", set()):
                continue
            memory["seen"].add(key)
            if prev.action in (R_HALF, R_POT) and cur.street == prev.street:
                memory["faced"][int(cur.street)] += 1
            elif prev.action == CALL and cur.street == prev.street and cur.street > 0 and prev.amount == 0:
                memory["opps"] += 1
                if cur.action in (R_HALF, R_POT):
                    memory["stabs"] += 1

    def on_hand_end(self, result, memory):
        lb = memory.get("last_bet")
        if lb is not None and lb[0] == result.hand_index and not result.went_to_showdown and result.winner == "me":
            memory["folded"][lb[1]] += 1      # we folded to its last bet (a fold is never
            memory["faced"][lb[1]] += 1       # visible in its history, so count it here)
        memory["last_bet"] = None
        if len(memory.get("seen", ())) > 5000:
            memory["seen"] = set()

    def choose_action(self, obs, memory):
        rng = memory["rng"]
        self._track(obs, memory)
        x = strength_pct(obs, rng)
        st = int(obs.street)
        fold_rate = memory["folded"][st] / memory["faced"][st]
        stab_rate = memory["stabs"] / memory["opps"]
        price = obs.to_call / (obs.pot + obs.to_call) if obs.to_call else 0.0
        act = None
        if obs.to_call == 0:
            if x > 0.78:
                act = _raise(obs, True)
            else:
                # Bluff if our fold rate beats the break-even for a pot (1/2) or half-pot (1/3) bet.
                ev_pot = fold_rate - (1 - fold_rate)          # x pot
                ev_half = fold_rate - (1 - fold_rate) * 0.5
                if max(ev_pot, ev_half) > 0.05 and x < 0.45 and rng.random() < 0.85:
                    act = _raise(obs, ev_pot > ev_half)
                else:
                    act = CALL
        else:
            # We bet: our range is wider the more often we stab.
            adj = 0.35 * (stab_rate - 0.4)
            if x > 0.9 and obs.raises_this_street < 3:
                act = _raise(obs, True)
            elif st == 0:
                act = CALL if x > 0.25 + price * 0.8 - adj or obs.to_call == 0 else FOLD
            else:
                act = CALL if x > 0.15 + price - adj else FOLD
        if act in (R_HALF, R_POT):
            memory["last_bet"] = (obs.hand_index, st)
        if act not in obs.legal_actions:
            act = CALL
        return act


# Parametric adversary: CEM-tuned against a fixed version of our bot by
# training/exploit.py.  Its best result is a lower bound on how exploitable
# that version is.
ADV_KEYS = ("pre_open", "pre_raise", "pre_call", "value", "bluff", "bluff_river", "pot_size",
            "def_base", "def_slope", "raise_vs_bet", "adapt")


class ParamAdversary(Exploiter):
    name = "adversary"

    def __init__(self, seed=0, theta=None, name=None):
        super().__init__(seed)
        self.th = dict(zip(ADV_KEYS, theta if theta is not None else [0.5] * len(ADV_KEYS)))
        if name:
            self.name = name

    def choose_action(self, obs, memory):
        rng, th = memory["rng"], self.th
        self._track(obs, memory)
        x = strength_pct(obs, rng)
        st = int(obs.street)
        fold_rate = memory["folded"][st] / memory["faced"][st]
        stab_rate = memory["stabs"] / memory["opps"]
        price = obs.to_call / (obs.pot + obs.to_call) if obs.to_call else 0.0
        if st == 0:
            if x > 0.5 + 0.5 * th["pre_raise"] and obs.raises_this_street < 3:
                act = _raise(obs, rng.random() < th["pot_size"])
            elif obs.to_call == 0 or x > th["pre_call"] * (0.3 + price):
                act = CALL if (len(obs.action_history) > 0 or x > th["pre_open"] * 0.6) else FOLD
            else:
                act = FOLD
        elif obs.to_call == 0:
            bluff = th["bluff_river"] if st == 3 else th["bluff"]
            bluff = float(np.clip(bluff + th["adapt"] * (fold_rate - 0.4) * 2, 0, 1))
            if x > 0.5 + 0.5 * th["value"]:
                act = _raise(obs, rng.random() < th["pot_size"])
            elif x < 0.5 and rng.random() < bluff:
                act = _raise(obs, rng.random() < th["pot_size"])
            else:
                act = CALL
        else:
            adj = th["adapt"] * 0.4 * (stab_rate - 0.4)
            if x > 0.7 + 0.3 * th["raise_vs_bet"] and obs.raises_this_street < 3:
                act = _raise(obs, True)
            else:
                act = CALL if x > 0.4 * th["def_base"] + th["def_slope"] * 1.5 * price - adj else FOLD
        if act in (R_HALF, R_POT):
            memory["last_bet"] = (obs.hand_index, st)
        if act not in obs.legal_actions:
            act = CALL
        return act


def train_pool(seed: int = 0) -> list:
    return [Starter(seed), GuideExample(seed), RandomBot(seed), CallingStation(seed), AlwaysHalf(seed),
            AlwaysPot(seed), Nit(seed), Maniac(seed), EquityBot(seed)]


def heldout_pool(seed: int = 0) -> list:
    return [TAG(seed), Sticky(seed)]


def style_pool(seed: int = 0) -> list:
    """Added for the optimisation round (also never used by tune.py)."""
    return [TightPassive(seed), LooseAggressive(seed), Balanced(seed), Exploiter(seed)]
