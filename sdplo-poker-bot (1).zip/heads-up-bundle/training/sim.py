"""
sim.py - fast in-process duplicate matches using the official game.py engine.

Bots here are plain objects with the same three methods as agent.py:
    new_half(config, memory), choose_action(obs, memory), on_hand_end(result, memory)

play_match() mirrors judge_engine.py: two halves on the same deals with seats
swapped, a fresh memory per half, hand results delivered before the next
decision, and the verdict from a 95% interval on bb per deal.  Illegal
actions or exceptions are counted as errors and replaced by the judge's
default action, like the real judge.
"""

from __future__ import annotations

import math
import os
import sys
import time
from dataclasses import dataclass, field

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from game import AgentConfig, BIG_BLIND, Game, button_for_deal, default_action, make_deal  # noqa: E402


@dataclass
class HalfStats:
    time: float = 0.0
    calls: int = 0
    errors: int = 0
    max_call: float = 0.0


@dataclass
class MatchResult:
    per_deal_bb: list = field(default_factory=list)   # agent A, both halves summed
    stats: dict = field(default_factory=dict)          # (bot, half) -> HalfStats

    @property
    def mean(self) -> float:
        return sum(self.per_deal_bb) / len(self.per_deal_bb)

    @property
    def se(self) -> float:
        n = len(self.per_deal_bb)
        m = self.mean
        var = sum((x - m) ** 2 for x in self.per_deal_bb) / (n - 1)
        return math.sqrt(var / n)

    @property
    def z(self) -> float:
        return self.mean / self.se if self.se > 0 else 0.0

    @property
    def verdict(self) -> str:
        lo, hi = self.mean - 1.96 * self.se, self.mean + 1.96 * self.se
        if any(s.errors >= 5 for (b, h), s in self.stats.items() if b == "A"):
            return "LOSS(forfeit)"
        if any(s.errors >= 5 for (b, h), s in self.stats.items() if b == "B"):
            return "WIN(forfeit)"
        return "WIN" if lo > 0 else "LOSS" if hi < 0 else "CHOP"


def play_half(bots: dict, seat_of: dict, seed, deals: int, stats: dict, half: int) -> list:
    """Play one half. bots: {'A': bot, 'B': bot}; seat_of: {'A': 0|1, 'B': 1|0}.
    Returns A's chip result per deal."""
    config = AgentConfig(num_hands=deals)
    mem = {k: {} for k in bots}
    for k, b in bots.items():
        b.new_half(config, mem[k])
        stats[(k, half)] = HalfStats()
    who = {seat_of[k]: k for k in bots}
    out = []
    for d in range(deals):
        game = Game(make_deal(seed, d), button_seat=button_for_deal(d), hand_index=d)
        while not game.is_terminal:
            seat = game.to_act
            k = who[seat]
            obs = game.observation(seat)
            st = stats[(k, half)]
            if st.errors >= 5:
                action = default_action(obs.to_call)
            else:
                t0 = time.perf_counter()
                try:
                    action = bots[k].choose_action(obs, mem[k])
                except Exception:
                    action = None
                dt = time.perf_counter() - t0
                st.time += dt
                st.calls += 1
                st.max_call = max(st.max_call, dt)
                if action not in obs.legal_actions:
                    st.errors += 1
                    action = default_action(obs.to_call)
            game.apply(action)
        for k in bots:
            try:
                bots[k].on_hand_end(game.hand_result(seat_of[k]), mem[k])
            except Exception:
                stats[(k, half)].errors += 1
        out.append(game.result().nets[seat_of["A"]])
    return out


def play_match(bot_a, bot_b, seed="0", deals: int = 1000) -> MatchResult:
    bots = {"A": bot_a, "B": bot_b}
    stats: dict = {}
    h1 = play_half(bots, {"A": 0, "B": 1}, seed, deals, stats, 1)
    h2 = play_half(bots, {"A": 1, "B": 0}, seed, deals, stats, 2)
    return MatchResult([(x + y) / BIG_BLIND for x, y in zip(h1, h2)], stats)
