"""timing.py - measure our bot's thinking time per decision and per 1000 hands."""
import sys, os
sys.path.insert(0, os.path.dirname(__file__)); sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from sim import play_match
from opponents import CallingStation, EquityBot, Maniac, Nit, SDPLOBot
from sdplo.params import load_params

def measure(params, deals=200, seed="timing"):
    p = dict(params); p["target_seconds"] = 1e9; p["hard_seconds"] = 1e9
    me = SDPLOBot(p, 1)
    tot = calls = 0; mx = 0.0; hands = 0
    for opp in [CallingStation(1), EquityBot(1), Maniac(1), Nit(1)]:
        r = play_match(me, opp, seed=seed, deals=deals)
        for h in (1, 2):
            s = r.stats[("A", h)]; tot += s.time; calls += s.calls; mx = max(mx, s.max_call)
        hands += 2 * deals
    return tot / calls * 1000, calls / hands, tot / hands * 1000, mx * 1000

if __name__ == "__main__":
    ms, dph, s1000, mx = measure(load_params())
    print(f"{ms:.2f} ms/decision, {dph:.2f} decisions/hand, {s1000:.2f} s per 1000 hands, slowest call {mx:.1f} ms")
