"""
tune.py - optimise strategy parameters by self-play + population matches.

Method: cross-entropy method (CEM) over the TUNABLE parameters in
sdplo/params.py.  Each generation:
  1. sample a population of parameter sets around the current mean
     (the mean itself is always included);
  2. every candidate plays duplicate matches against the training pool:
     scripted opponents of different styles (random, passive, aggressive,
     tight, equity-based) plus a LEAGUE of frozen earlier versions of our own
     bot (self-play), all on the SAME seeds (common random numbers);
  3. fitness = sum over opponents of 3*tanh(z/3), z = mean/SE of bb per deal.
     This mirrors the tournament: it rewards turning chops into significant
     wins, but saturates on opponents we already beat easily, so crushing a
     weak bot harder cannot buy a loss against a stronger one;
  4. the top 25% become the next mean / std.

Each generation's mean is checkpointed to checkpoints/gen_XX.json and a log
line goes to training/logs/tune_log.jsonl.  Held-out opponents (tag, sticky)
and "eval-" seeds are never used here, so evaluate.py stays an honest test.

    python training/tune.py --generations 8 --pop 12 --deals 300 --seed 0
    python training/tune.py --resume checkpoints/gen_07.json ...
"""

from __future__ import annotations

import argparse
import json
import math
import os
import sys
import time
from multiprocessing import Pool

import numpy as np

sys.path.insert(0, os.path.dirname(__file__))
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from opponents import (AlwaysPot, CallingStation, EquityBot, Maniac, Nit, RandomBot,  # noqa: E402
                       SDPLOBot)
from sdplo.params import DEFAULTS, TUNABLE, load_params  # noqa: E402
from sim import play_match  # noqa: E402

ROOT = os.path.join(os.path.dirname(__file__), "..")
CKPT = os.path.join(ROOT, "checkpoints")
LOGS = os.path.join(os.path.dirname(__file__), "logs")
NAMES = list(TUNABLE)   # may be narrowed with --keys


def to_unit(p: dict) -> np.ndarray:
    return np.array([(p[k] - TUNABLE[k][0]) / (TUNABLE[k][1] - TUNABLE[k][0]) for k in NAMES])


def from_unit(u: np.ndarray, base: dict) -> dict:
    p = dict(base)
    for k, x in zip(NAMES, np.clip(u, 0.0, 1.0)):
        lo, hi = TUNABLE[k]
        p[k] = float(lo + x * (hi - lo))
    return p


def make_opponent(spec):
    kind, arg = spec
    if kind == "league":
        return SDPLOBot(arg[1], seed=11, name=arg[0])
    if arg.startswith("adv:"):
        import opponents as O
        with open(arg[4:]) as f:
            return O.ParamAdversary(seed=11, theta=json.load(f)["theta"])
    import opponents as O
    reg = {o.name: type(o) for o in O.train_pool() + O.style_pool()}
    return reg[arg](11)


def _match(args):
    cand_id, params, opp_spec, seed, deals = args
    r = play_match(SDPLOBot(params, seed=5), make_opponent(opp_spec), seed=seed, deals=deals)
    errs = sum(s.errors for (b, _h), s in r.stats.items() if b == "A")
    return cand_id, (opp_spec[1] if opp_spec[0] == "pool" else opp_spec[1][0]), r.mean, r.se, errs


def fitness(rows) -> float:
    total = 0.0
    for _name, m, se, errs in rows:
        if errs >= 5:
            return -100.0
        z = m / se if se > 0 else 0.0
        total += 3.0 * math.tanh(z / 3.0)
    return total


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--generations", type=int, default=8)
    ap.add_argument("--pop", type=int, default=12)
    ap.add_argument("--deals", type=int, default=300)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--procs", type=int, default=2)
    ap.add_argument("--std", type=float, default=0.15)
    ap.add_argument("--resume", default=None, help="parameter file to start from")
    ap.add_argument("--start-gen", type=int, default=0)
    ap.add_argument("--pool", nargs="*", default=["equity_bot", "nit", "maniac", "calling_station", "random", "always_pot"],
                    help="training opponents (names from opponents.py, or adv:FILE.json)")
    ap.add_argument("--keys", nargs="*", default=None, help="subset of TUNABLE to optimise")
    ap.add_argument("--ckpt-prefix", default="gen")
    a = ap.parse_args()

    global NAMES
    if a.keys:
        NAMES = [k for k in a.keys if k in TUNABLE]
    os.makedirs(CKPT, exist_ok=True)
    os.makedirs(LOGS, exist_ok=True)
    rng = np.random.default_rng(a.seed)
    base = load_params(a.resume) if a.resume else dict(DEFAULTS)
    mean = to_unit(base)
    std = np.full(len(NAMES), a.std)
    league = [("start", dict(base))]
    pool = a.pool

    for g in range(a.start_gen, a.start_gen + a.generations):
        t0 = time.time()
        cands = [mean] + [mean + std * rng.standard_normal(len(NAMES)) for _ in range(a.pop - 1)]
        cands = [np.clip(c, 0, 1) for c in cands]
        params = [from_unit(c, base) for c in cands]
        opps = [("pool", n) for n in pool] + [("league", lg) for lg in league[-2:]]
        seeds = [f"train-{a.seed}-g{g}-{i}" for i in range(len(opps))]   # one seed per opponent slot
        jobs = [(ci, params[ci], o, s, a.deals) for ci in range(len(cands)) for o, s in zip(opps, seeds)]
        with Pool(a.procs) as p:
            out = p.map(_match, jobs)
        rows = {ci: [] for ci in range(len(cands))}
        for ci, name, m, se, errs in out:
            rows[ci].append((name, m, se, errs))
        fit = np.array([fitness(rows[ci]) for ci in range(len(cands))])
        order = np.argsort(-fit)
        n_elite = max(2, len(cands) // 4)
        elite = np.array([cands[i] for i in order[:n_elite]])
        mean = 0.7 * elite.mean(0) + 0.3 * mean
        std = np.maximum(0.7 * elite.std(0) + 0.3 * std, 0.03)
        gen_params = from_unit(mean, base)
        path = os.path.join(CKPT, f"{a.ckpt_prefix}_{g:02d}.json")
        with open(path, "w") as f:
            json.dump(gen_params, f, indent=1)
        league.append((f"{a.ckpt_prefix}_{g:02d}", gen_params))
        best = order[0]
        log = {"gen": g, "seconds": round(time.time() - t0, 1), "fit_mean_candidate": round(float(fit[0]), 3),
               "fit_best": round(float(fit[best]), 3), "fit_median": round(float(np.median(fit)), 3),
               "best_rows": [(n, round(m, 3), round(se, 3)) for n, m, se, _ in rows[best]],
               "mean_params": {k: round(gen_params[k], 4) for k in NAMES},
               "std": {k: round(float(s), 3) for k, s in zip(NAMES, std)}}
        with open(os.path.join(LOGS, f"{a.ckpt_prefix}_log.jsonl" if a.ckpt_prefix != "gen" else "tune_log.jsonl"), "a") as f:
            f.write(json.dumps(log) + "\n")
        print(f"gen {g}: best {fit[best]:.2f}  mean-candidate {fit[0]:.2f}  median {np.median(fit):.2f}  "
              f"({log['seconds']}s) -> {path}", flush=True)


if __name__ == "__main__":
    main()
